import { BrowserModule } from '@angular/platform-browser';
import { APP_INITIALIZER, NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { HttpClientModule } from '@angular/common/http';
import {MatInputModule} from '@angular/material/input';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule} from '@angular/material/button';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { httpInterceptorProviders } from './services/interceptors';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { SharedModule } from './modules/shared/shared.module';
import { AppInitService } from './services/init.service';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatIconModule } from '@angular/material/icon';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatCardModule} from '@angular/material/card';
import {MatListModule} from '@angular/material/list';
import { AppMaterialModule } from './modules/app-material/app-material.module';
import { CommonService } from './layout/common.service';
import { CaptchaComponent } from './components/captcha/captcha.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    CaptchaComponent
  ],
  imports: [
    BrowserModule,
    AppMaterialModule,
    BrowserAnimationsModule,
    HttpClientModule,
    MatInputModule,
    MatButtonModule,
    MatSnackBarModule,
    ReactiveFormsModule,
    SharedModule,
    MatIconModule,
    FlexLayoutModule,
    AppRoutingModule,
    MatSidenavModule,
    MatCardModule,
    MatListModule,
    FormsModule,
  ],
  exports:[AppMaterialModule,MatSidenavModule],
  providers: [
    httpInterceptorProviders,
    AppInitService,
    CommonService,
    { provide: APP_INITIALIZER, useFactory: init, deps: [AppInitService], multi: true },
    { provide: APP_INITIALIZER, useFactory: loadUrls, deps: [AppInitService], multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
export function init(appInitService: AppInitService) {
  return () => appInitService.init();
}
export function loadUrls(appInitService: AppInitService) {
  return () => appInitService.loadUrls();
}
