import { Component } from '@angular/core';
import { environment } from 'src/environments/environment';
import { APMService } from './apm-rum';
import { AuthService } from './services/auth.service';
import { UiService } from './services/ui.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  constructor(private ui: UiService, private apm: APMService, private auth: AuthService) {
    document.getElementById('loader').className = 'hidden-loader';
    this.apm.initializeApm(environment, {
      '/dashboard': 'Dashboard, User',
      '/openitems': 'Open Items, User',
      '/pendingwithothers': 'Pending with Others, User',
      '/swifttracking': 'Swift Tracking, User'
    });
    if (this.auth.getUser()) {
      let u = this.auth.getUser();
      this.apm.setUserContext(u.domain, u.employeeName, u.emailID);
    }
  }
}
