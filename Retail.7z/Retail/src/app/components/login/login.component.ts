import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { AuthService } from 'src/app/services/auth.service';
import { NotifyService } from 'src/app/services/notify.service';
import { PermissionService } from 'src/app/services/perm.service';
import { UiService } from 'src/app/services/ui.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(private auth: AuthService, private perm: PermissionService, 
    private router: Router, private ns: NotifyService, private ui: UiService) {
      this.ui.setMetaData({
        title: 'RIL-EBRC | Login'
      })
  }
  loginForm: FormGroup;
  refreshCaptcha = new Subject();
  hide: boolean = true;
  ngOnInit(): void {
    if (this.auth.getUser()) {
      if (this.auth.isAuthorized()) {
        // this.router.navigate(['transfer-pricing-details'])
       this.router.navigate(['login_form']);
      }
      else {
        this.auth.loginWithCookie().subscribe(r => {
         // this.perm.getPermissions().subscribe(s => {
            // this.router.navigate(['transfer-pricing-details']);
            this.router.navigate(['login_form']);
        //  });
        });
      }
    }
    this.loginForm = new FormGroup({
      username: new FormControl(null, [Validators.required]),
      password: new FormControl(null, [Validators.required, Validators.minLength(6)]),
      captchaData: new FormControl({
        captchaId: null,
        captchaValue: null
      })
    })
  }

  onSubmit(form) {
    let obj = {
      ccode: form.captchaData.captchaId,
      cvalue: form.captchaData.captchaValue,
      username: form.username,
      password: form.password
    }
    this.auth.login(obj).subscribe(res => {
     // this.perm.getPermissions().subscribe(res => {
      //  this.router.navigate(['transfer-pricing-details']);
     this.router.navigate(['login_form']);
     // });
    }, err => {
      this.ns.errorMessage(err.error.OPStatus.Status);
      this.refreshCaptcha.next();
      this.loginForm.controls['password'].setValue('');
      //this.ns.errorMessage(err);
    })
  }

}
