import { Component, Input, forwardRef, OnInit, OnChanges, Output, EventEmitter, ElementRef, ViewChild } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR, FormControl } from '@angular/forms';
import { ReplaySubject } from 'rxjs';
import { SearchByKeyFilterPipe } from 'src/app/pipes/dynamic.pipe';

@Component({
  selector: 'ngx-select',
  templateUrl: './ngx-custom.component.html',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => NgxCustomComponent),
      multi: true
    },
    SearchByKeyFilterPipe
  ],
  styleUrls: ['./ngx-custom.component.css']
})
export class NgxCustomComponent implements ControlValueAccessor, OnChanges  {
  @Input() isAE = false; 
  @Input() name: string;
  @Input('bindValue') bindValue: string;
  @Input('bindName') bindName: string;
  @Input('optionalName') oName: string;
  @Input('value') val: string;
  @Input() disabled = false;
  @Input() multiple = false;
  @Input() placeholder: string;
  @Input() inputList: any;
  @Input() readonly: boolean = false;
  @Output() openedChange: EventEmitter<any> = new EventEmitter<any>();
  @Output() changes: EventEmitter<any> = new EventEmitter<any>();
  @Output() changesNew: EventEmitter<any> = new EventEmitter<any>();
  @Input() selectAll: boolean;
  @Input() required: boolean = false;
  @ViewChild('checkBox') checkBox: ElementRef;
  backUpValue: any;
  constructor(private _searchByKeyFilter: SearchByKeyFilterPipe) { }
  filteredCodesControl = new FormControl();
  selectAllControl = new FormControl();
  selectAllBox = new FormControl();
  public filteredCodes: ReplaySubject<any> = new ReplaySubject<any>(1);
  listLength: number;
  onChange: any = () => { };
  onTouched: any = () => { };
  ngOnChanges() {
    if (this.inputList)
      this.listLength = this.inputList.length;
    if (this.selectAll && this.inputList && !(this.inputList.length === 0) && this.checkBox)
      this.checkBox['checked'] = false;
    this.selectAll = this.selectAll ? this.selectAll : this.multiple;
    this.filteredCodes.next(this.inputList);
    this.filteredCodesControl.valueChanges
      .subscribe(() => {
        this.filteredCodes.next(this._searchByKeyFilter.transform(this.inputList, this.filteredCodesControl.value, this.bindName, this.oName));
      });
  }
  selectAllEvent(checked) {
    if (this.readonly)
      return;
    if (!checked) {
      this.value = this.inputList.map(key => key[this.bindValue]);
    }
    else {
      this.value = null;
    }
    this.changes.emit(event);
  }
  get value() {
    return this.val;
  }
  set value(val) {
    this.val = val;
    this.onChange(val);
    this.onTouched();
  }
  registerOnChange(fn) {
    this.onChange = fn;
  }
  registerOnTouched(fn) {
    this.onTouched = fn;
  }
  writeValue(value) {
    if (value && value.length === 0)
      this.selectAllBox.setValue(false);
    if (this.selectAll && this.inputList && this.inputList.length !== 0 && this.checkBox)
      if (value && value.length === this.listLength)
        this.checkBox['checked'] = true;
      else
        this.checkBox['checked'] = false;
    if (value || value === null) {
      this.value = value;
    }
  }
 

  openChangeEmit(event) {
    this.openedChange.emit(event);
  }

  setDisabledState(isDisabled: boolean) {
    this.disabled = isDisabled;
  }

  selectionChangeEmit(event) {
    if (this.selectAll && this.inputList && !(this.inputList.length === 0) && this.checkBox)
      if (event.value && event.value.length === this.listLength)
        this.checkBox['checked'] = true;
      else
        this.checkBox['checked'] = false;
    this.changes.emit(event);
  }

  clearBackUp() {
    this.backUpValue = undefined;
    this.changesNew.emit({​​​​value: this.value}​​​​) 
  }
}