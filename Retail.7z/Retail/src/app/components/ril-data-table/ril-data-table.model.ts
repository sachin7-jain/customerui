import { MatTableDataSource } from '@angular/material/table';

export class RilTableModel {

    btnActionFilter: boolean = false;
    btnActionAdd: boolean = false;
    btnActionSetting: boolean = false;
    btnActionExcel: boolean = false;
    btnActionDownload: boolean = false;
    btnActionUpload: boolean = false;
    btnActionPdf: boolean = false;
    btnActionFetch: boolean = false;
    btnActionCalculate: boolean = false;
    btnActionImport: boolean = false;
    btnActionSave: boolean = false;
    btnActionApproval: boolean = false;
    btnActionApproval1: boolean = false;
    btnActionRupee: boolean = false;
    btnActionDeleteFlag: boolean = false;
    btnActionHistory: boolean = false;
    btnActionAttachment: boolean = false;
    btnActionBack: boolean = false;
    btnActionEditFlag: boolean = false;
    btnActionDownloadAttachment: boolean = false;
    btnActionApprove:boolean=false;
    headerneeded: boolean = false;
    isdisabled: boolean = false;
    dataSource: any[] = [];
    columns: any[] = [];
    displayedColumns: Array<any> = [];
    headerColumns: any[] = [];
    selectedRecords: any[] = [];
    displayedSubHeading: any[] = [];
    btnAdvanceFilter: boolean = false;
    validatedStatus: boolean = false;
    colSelect: boolean = true;
    colAction: boolean = true;
    btnActionDelete: boolean = false;
    btnActionEdit: boolean = false;
    btnActionDisplay: boolean = false;
    btnActionAttach: boolean = false;
    btnActionSendBack: boolean = false;
    btnActionPushTP: boolean = false;
    btnActionComplete: boolean = false;
    btnActionClock: boolean = false;
    footer: boolean = false;
    tableShow: boolean = true
    toogleStatus: boolean = false;
    toogleRadio: boolean = false;
    clubexp: boolean = false;
    penaltyind: boolean = false;
    disableCheck: boolean = false;
    paginatorShow: boolean = false;
    showSearch:boolean=true;
    pageSizeOptions: any = [5, 10, 25, 100];
    pageSize: any = 5;
    showTotalPages: boolean = true;
    aval: any[] = [];
    showData: boolean = false;
    isConfirmDelete: boolean = true;
    isPostCollection: boolean = false;
    isRowSpan:boolean =false;
    permObj : string = "";
    btnprivliages: any = {
        btnAdvanceFilter: false,
        btnActionAdd: false,
        btnActionSetting: false,
        btnActionExcel: false,
        btnActionDownload: false,
        btnActionUpload: false,
        btnActionPdf: false,
        btnActionFetch: false,
        btnActionCalculate: false,
        btnActionImport: false,
        btnActionSave: false,
        btnActionApproval: false,
        btnActionRupee: false,
        btnActionDeleteFlag: false,
        btnActionDelete: false,
        btnActionEdit: false,
        btnActionDisplay: false,
        btnActionApprove: false,
        btnActionHistory: false,
        btnActionBack: false,
        btnActionEditFlag: false,
        btnActionDownloadAttachment: false,
        isConfirmDelete: true,
        isPostCollection: false
    }
    private _oMatTableDataSource: MatTableDataSource<any[]>;

    get oMatTableDataSource(): MatTableDataSource<any[]> {
        this._oMatTableDataSource = new MatTableDataSource(this.dataSource);
        return this._oMatTableDataSource;
    }
}

export enum edittype {
    INPUT,
    SELECT,
    TOGGLE,
    TEXTAREA,
    RADIO,
    NONE
}