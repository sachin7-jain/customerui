import { Component, ViewChild, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { RilTableModel, edittype } from './ril-data-table.model';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { FormGroup, FormControl } from '@angular/forms';
import { SharedService } from 'src/app/services/shared.service';
import { MatDialog } from '@angular/material/dialog';
import { PERM } from 'src/app/constants/const';
import { CookieService } from 'src/app/services/cookie.service';
import { PermissionService } from 'src/app/services/perm.service';
@Component({
  selector: 'lib-ril-data-table',
  templateUrl: './ril-data-table.component.html',
  styleUrls: ['./ril-data-table.component.scss'],
  providers:[SharedService]
})
export class RilDataTableComponent implements OnChanges {
  spans = [];
  _oDataSource: any;
  objFilterValue: any;
  _defaultColumns: string[] = [];
  
  permObj = PERM;
  config = {
    backdrop: true,
    ignoreBackdropClick: true
  };
  edittype = edittype;
  @ViewChild('DisplayCols') DisplayCols;
  @ViewChild('myDialog') myDialog;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @Input() tableName: string;
  @Input() oInputRilTableModel: RilTableModel;
  @Input() oChangeTrigger: number;
  @Output() onAdd = new EventEmitter<any>();
  @Output() onDeleteRow = new EventEmitter<any>();
  @Output() onEditRow = new EventEmitter<any>();
  @Output() onStatusChange = new EventEmitter<any>();
  @Output() onStatusChangeclub = new EventEmitter<any>();
  @Output() onStatusUpdate = new EventEmitter<any>();
  @Output() onDisplayRow = new EventEmitter<any>();
  @Output() onApproveRow =new EventEmitter<any>();
  @Output() onDataSetting = new EventEmitter<any>();
  @Output() onExcelDownload = new EventEmitter<any>();
  @Output() onDownload = new EventEmitter<any>();
  @Output() onUpload = new EventEmitter<any>();
  @Output() onPdfDownload = new EventEmitter<any>();
  @Output() onSave = new EventEmitter<any>();
  @Output() onImport = new EventEmitter<any>();
  @Output() onFetch = new EventEmitter<any>();
  @Output() onCalculate = new EventEmitter<any>();
  @Output() onApproval = new EventEmitter<any>();
  @Output() onApproval1 = new EventEmitter<any>();
  @Output() onRupee = new EventEmitter<any>();
  @Output() onCertificateDownload = new EventEmitter<any>();
  @Output() onHistory = new EventEmitter<any>();
  @Output() onAttachment = new EventEmitter<any>();
  @Output() onCheckBoxClick = new EventEmitter<any>();
  @Output() onBack = new EventEmitter<any>();
  @Output() onAttach = new EventEmitter<any>();
  @Output() onRowAttachment = new EventEmitter<any>();
  @Output() onRefresh = new EventEmitter<any>();
  @Output() onColumnSave = new EventEmitter<any>();
  @Output() editChange = new EventEmitter<any>();
  textareaValue;
  selectedItem;
  searchForm: FormGroup;
  size = 2;
  pageIndex = 0;
  dataSource: any;
  xlsColumns: string[] = [];
  excelDownloadData:any;
  constructor(
    private _sharedService: SharedService, 
    private dialog: MatDialog,
    private perm: PermissionService
  ) {
  }

  ngOnChanges() {
    this.xlsColumns = [];
    this.initializeTable();
    this.initializeSearchForm();
   
    this.bindTable();
    if (this.objFilterValue != "" && this.objFilterValue != undefined) {
      this.applyFilter(this.objFilterValue)
    }
    this.permObj.Preparer = [{
      ob: this.oInputRilTableModel.permObj,
      actvt: "Preparer"
    }]
  }

  initializeTable() {
    this.oInputRilTableModel.btnActionSetting = this.oInputRilTableModel.btnprivliages.btnActionSetting ? this.oInputRilTableModel.btnprivliages.btnActionSetting : this.oInputRilTableModel.btnActionSetting;
    this.oInputRilTableModel.btnAdvanceFilter = this.oInputRilTableModel.btnprivliages.btnAdvanceFilter ? this.oInputRilTableModel.btnprivliages.btnAdvanceFilter : this.oInputRilTableModel.btnAdvanceFilter;
    this.oInputRilTableModel.btnActionBack = this.oInputRilTableModel.btnprivliages.btnActionBack ? this.oInputRilTableModel.btnprivliages.btnActionBack : this.oInputRilTableModel.btnActionBack;
    this.oInputRilTableModel.btnActionRupee = this.oInputRilTableModel.btnprivliages.btnActionRupee ? this.oInputRilTableModel.btnprivliages.btnActionRupee : this.oInputRilTableModel.btnActionRupee;
    this.oInputRilTableModel.btnActionHistory = this.oInputRilTableModel.btnprivliages.btnActionHistory ? this.oInputRilTableModel.btnprivliages.btnActionHistory : this.oInputRilTableModel.btnActionHistory;
    this.oInputRilTableModel.btnActionAttach = this.oInputRilTableModel.btnprivliages.btnActionAttach ? this.oInputRilTableModel.btnprivliages.btnActionAttach : this.oInputRilTableModel.btnActionAttach;
    this.oInputRilTableModel.btnActionAttachment = this.oInputRilTableModel.btnprivliages.btnActionAttachment ? this.oInputRilTableModel.btnprivliages.btnActionAttachment : this.oInputRilTableModel.btnActionAttachment;
    this.oInputRilTableModel.btnActionDownloadAttachment = this.oInputRilTableModel.btnprivliages.btnActionDownloadAttachment ? this.oInputRilTableModel.btnprivliages.btnActionDownloadAttachment : this.oInputRilTableModel.btnActionDownloadAttachment;
    this.oInputRilTableModel.btnActionAdd = this.oInputRilTableModel.btnprivliages.btnActionAdd ? this.oInputRilTableModel.btnprivliages.btnActionAdd : this.oInputRilTableModel.btnActionAdd;
    this.oInputRilTableModel.btnActionDownload = this.oInputRilTableModel.btnprivliages.btnActionDownload ? this.oInputRilTableModel.btnprivliages.btnActionDownload : this.oInputRilTableModel.btnActionDownload;
    this.oInputRilTableModel.btnActionUpload = this.oInputRilTableModel.btnprivliages.btnActionUpload ? this.oInputRilTableModel.btnprivliages.btnActionUpload : this.oInputRilTableModel.btnActionUpload;
    this.oInputRilTableModel.btnActionPdf = this.oInputRilTableModel.btnprivliages.btnActionPdf ? this.oInputRilTableModel.btnprivliages.btnActionPdf : this.oInputRilTableModel.btnActionPdf;
    this.oInputRilTableModel.btnActionFetch = this.oInputRilTableModel.btnprivliages.btnActionFetch ? this.oInputRilTableModel.btnprivliages.btnActionFetch : this.oInputRilTableModel.btnActionFetch;
    this.oInputRilTableModel.btnActionCalculate = this.oInputRilTableModel.btnprivliages.btnActionCalculate ? this.oInputRilTableModel.btnprivliages.btnActionCalculate : this.oInputRilTableModel.btnActionCalculate;
    this.oInputRilTableModel.btnActionImport = this.oInputRilTableModel.btnprivliages.btnActionImport ? this.oInputRilTableModel.btnprivliages.btnActionImport : this.oInputRilTableModel.btnActionImport;
    this.oInputRilTableModel.btnActionSave = this.oInputRilTableModel.btnprivliages.btnActionSave ? this.oInputRilTableModel.btnprivliages.btnActionSave : this.oInputRilTableModel.btnActionSave;
    this.oInputRilTableModel.btnActionApproval = this.oInputRilTableModel.btnprivliages.btnActionApproval ? this.oInputRilTableModel.btnprivliages.btnActionApproval : this.oInputRilTableModel.btnActionApproval;
    this.oInputRilTableModel.btnActionApproval1 = this.oInputRilTableModel.btnprivliages.btnActionApproval1 ? this.oInputRilTableModel.btnprivliages.btnActionApproval1 : this.oInputRilTableModel.btnActionApproval1;
    this.oInputRilTableModel.btnActionDeleteFlag = this.oInputRilTableModel.btnprivliages.btnActionDeleteFlag ? this.oInputRilTableModel.btnprivliages.btnActionDeleteFlag : this.oInputRilTableModel.btnActionDeleteFlag;
    this.oInputRilTableModel.btnActionDelete = this.oInputRilTableModel.btnprivliages.btnActionDelete ? this.oInputRilTableModel.btnprivliages.btnActionDelete : this.oInputRilTableModel.btnActionDelete;
    this.oInputRilTableModel.btnActionEdit = this.oInputRilTableModel.btnprivliages.btnActionEdit ? this.oInputRilTableModel.btnprivliages.btnActionEdit : this.oInputRilTableModel.btnActionEdit;
    this.oInputRilTableModel.btnActionDisplay = this.oInputRilTableModel.btnprivliages.btnActionDisplay ? this.oInputRilTableModel.btnprivliages.btnActionDisplay : this.oInputRilTableModel.btnActionDisplay;
    this.oInputRilTableModel.btnActionApprove = this.oInputRilTableModel.btnprivliages.btnActionApprove ? this.oInputRilTableModel.btnprivliages.btnActionApprove : this.oInputRilTableModel.btnActionApprove;
    this.oInputRilTableModel.btnActionEditFlag = this.oInputRilTableModel.btnprivliages.btnActionEditFlag ? this.oInputRilTableModel.btnprivliages.btnActionEditFlag : this.oInputRilTableModel.btnActionEditFlag;
    this.oInputRilTableModel.btnActionExcel = this.oInputRilTableModel.btnprivliages.btnActionExcel ? this.oInputRilTableModel.btnprivliages.btnActionExcel : this.oInputRilTableModel.btnActionExcel;
    this.oInputRilTableModel.isConfirmDelete = this.oInputRilTableModel.btnprivliages.isConfirmDelete ? this.oInputRilTableModel.btnprivliages.isConfirmDelete : this.oInputRilTableModel.isConfirmDelete;
    this.oInputRilTableModel.isPostCollection = this.oInputRilTableModel.btnprivliages.isPostCollection ? this.oInputRilTableModel.btnprivliages.isPostCollection : this.oInputRilTableModel.isPostCollection;
  }

  paginate(event: any) {
    this.pageIndex = event;
    this._oDataSource = this.oInputRilTableModel.dataSource.slice(
      event * this.size - this.size,
      event * this.size
    );
  }
  initializeSearchForm() {
    this.searchForm = new FormGroup({
      searchInput: new FormControl(),
    });
  }

  bindTable() {
    if(this.oInputRilTableModel.isRowSpan){
      let arr=[];
      this.excelDownloadData=this.oInputRilTableModel.dataSource.map(x=>{
          x.items.map(y=>{
            y["name_of_ae"]=x.name_of_ae;
            y["taxno"]=x.taxno;
            y["related_party_type"]=x.related_party_type;
           // y["id"]=y.id;
            arr.push(y);
            return arr;
          })
        })
      this.excelDownloadData=new MatTableDataSource(arr);
      const array = this.oInputRilTableModel.dataSource.reduce((current, next) => {
        next.items=next.items.map(r=>{
          r["offset_gl_original"]=r["offset_gl"];
           r["offset_gl"]=r["desc_offset_gl"]+" ("+r.offset_gl+")";
           return r;
        })       
        next.items.forEach((pair) => {         
          current.push({id:next.id, taxno: next.taxno,name_of_ae: next.name_of_ae,related_party_type:next.related_party_type, items: pair });
        });
        return current;
      }, []);
      this.cacheSpan(array);
      //this._oDataSource = array;
      this._oDataSource = new MatTableDataSource(array);
    }else{
      this._oDataSource = new MatTableDataSource(this.oInputRilTableModel.dataSource ? this.oInputRilTableModel.dataSource : []);
    }
    if (this.oInputRilTableModel.dataSource.length == 0) {
      this.oInputRilTableModel.showData = true;
    } else {
      this.oInputRilTableModel.showData = false;
    }
    // setTimeout(() => {
    //   this._oDataSource.paginator = this.paginator;  this._oDataSource.sort = this.sort;
    // });

  }


  applyFilter(filterValue: string) {
    filterValue = String(filterValue);
    this.objFilterValue = filterValue;
    this._oDataSource.filter = filterValue.trim().toLowerCase();
      if (this._oDataSource.filteredData.length === 0) {
        this.oInputRilTableModel.showData = true;
      } else {
        this.oInputRilTableModel.showData = false;
        this._oDataSource.filter = filterValue.trim().toLowerCase();
      }
    if (this._oDataSource.paginator) {
      this._oDataSource.paginator.firstPage();
    }
  }

  keyPressHandler(e) {
    if (e.keyCode === 13) {
      e.preventDefault();
      e.stopPropagation();
    }
  }


  onAddBtn() {
    this.onAdd.emit();
  }

  onDataSettingBtn(data) {
    this.onDataSetting.emit(data);
  }
  onExcelDownloadBtn() {  
    if (this._oDataSource.sort){
      if(this.oInputRilTableModel.isRowSpan){      
        this.createDownloadExcel(this.excelDownloadData.sortData(this.excelDownloadData.filteredData, this._oDataSource.sort));
      }else{
        this.createDownloadExcel(this._oDataSource.sortData(this._oDataSource.filteredData, this._oDataSource.sort));
      }
    }     
    else{
      if(this.oInputRilTableModel.isRowSpan){      
        this.createDownloadExcel(this.excelDownloadData.filteredData);
      }else{
        this.createDownloadExcel(this._oDataSource.filteredData);
      }
    }
      
  }
  createDownloadExcel(data) {
    if (data.length <= 0) {
      this._sharedService.openSnackBar("No data to download");
      return false;
    }
    let tableHeaders = this.oInputRilTableModel.columns;
    let tableHeadersNames = this.oInputRilTableModel.displayedColumns.filter(val => val != 'SelectAllColumn');
    let exportHeaders = [];
    if (this.xlsColumns.length > 0) {
      for (let i = 0; i < tableHeaders.length; i++) {
        let obj = {};
        for (let j = 0; j < this.xlsColumns.length; j++) {
          if (this.xlsColumns[j] == tableHeaders[i].columnDef) {
            let keyName = tableHeaders[i].columnDef;
            let type = typeof (data[0][keyName]);
            obj["json_key"] = tableHeaders[i].columnDef;
            obj["column_name"] = tableHeaders[i].header;
            obj["type"] = type;
            exportHeaders.push(obj);
          }
        }
      }
    } else {
      for (let i = 0; i < tableHeaders.length; i++) {
        let obj = {};
        for (let j = 0; j < tableHeadersNames.length; j++) {
          if (tableHeadersNames[j] == tableHeaders[i].columnDef) {
            let keyName = tableHeaders[i].columnDef;
            let type = typeof (data[0][keyName]);
            obj["json_key"] = tableHeaders[i].columnDef;
            obj["column_name"] = tableHeaders[i].header;
            obj["type"] = type;
            exportHeaders.push(obj);
          }
        }
      }
    }
    this._sharedService.downloadExcelFile(this.tableName + 'Data', data, exportHeaders);
  }
  // onExcelDownloadBtn() {
  //   this.onExcelDownload.emit();
  // }

  onDownloadBtn() {
    this.onDownload.emit();
  }

  onUploadBtn() {
    this.onUpload.emit();
  }

  onPdfDownloadBtn() {
    this.onPdfDownload.emit();
  }

  onRowDelete(row) {
    this.onDeleteRow.emit(row);
    }

  onRowEdit(row,i) {
    this.onEditRow.emit(row);
  }

  onRowDisplay(row) {
    this.onDisplayRow.emit(row);
  }
  onRowApprove(row) {
    this.onApproveRow.emit(row);
  }
  
  onSaveBtn() {
    this.onSave.emit(this._oDataSource.data);
  }

  onImportBtn() {
    this.onImport.emit();
  }

  onCalculateBtn() {
    this.onCalculate.emit();
  }

  onFetchBtn() {
    this.onFetch.emit();
  }

  onBackBtn() {
    this.onBack.emit();
  }

  onApprovalBtn() {
    this.onApproval.emit(this._oDataSource.data)
  }


  onRupeeBtn() {
    this.onRupee.emit()
  }


  onAttachBtn(item) {
    this.onAttach.emit(item)
  }

  onHistoryBtn() {
    this.onHistory.emit()
  }

  onAttachmentBtn() {
    this.onAttachment.emit()
  }

  clearResults(e){
    console.log(e);
    
  }

  sendBack(e){

  }

  complete(e){

  }

  pushTP(e){

  }
  // onSlideChange(event, object) {
  //   object["createdBy"] = null;
  //   object["isActive"] = event.checked;
  //   let passObject = { checked: event.checked, data: object };
  //   this.onStatusUpdate.emit(passObject);
  // }
  onEditInput(e,i){
    this.editChange.emit(e)
  }

  onDispalyColumnChange(value) {
    let DynamicColDisp: string[] = [];
    let downloadColumns: string[] = [];
    try {
      if (this.oInputRilTableModel.toogleRadio) {
        DynamicColDisp.push('RadioSelect');
      }
      if (value.value.length > 0) {
        value.value.forEach(element => {
          if (element == "validatedOnDeptWebSite") {
            DynamicColDisp.push("certificate");
          }
          DynamicColDisp.push(element);
          downloadColumns.push(element);
        });
        this._defaultColumns = DynamicColDisp;
      } else {
        // this._messageService.sendMessage('Atleast one column should be selected.');
        this._defaultColumns.forEach(element => {
          if (!(DynamicColDisp.indexOf(element) > -1))
            DynamicColDisp.push(element);
        });
      }
      if (this.oInputRilTableModel.toogleStatus) {
        DynamicColDisp.push('isActiveStatus');
      }
      if (this.oInputRilTableModel.penaltyind) {
        DynamicColDisp.push('penaltyind');
      }
      if (this.oInputRilTableModel.clubexp) {
        DynamicColDisp.push('clubexp');
      }
      if (this.oInputRilTableModel.validatedStatus) {
        DynamicColDisp.push('Validated');
      }
      if (!(DynamicColDisp.indexOf("action") > -1) && this.oInputRilTableModel.colAction) {
        DynamicColDisp.push("action");
      }
      this.oInputRilTableModel.displayedColumns = DynamicColDisp;
      this.xlsColumns = (downloadColumns);
    } catch (error) {
    }
  }
  onRowCertificate(row) {
    this.onCertificateDownload.emit(row)
  }
  onChange(item) {
    this.oInputRilTableModel.selectedRecords.push(item)
  }
  onChangePenaltyInd(row) {
    this.onStatusChange.emit(row);
  }


  onChangeClubExp(row) {
    this.onStatusChangeclub.emit(row);
  }

  itemclickradio(row) {
    this.oInputRilTableModel.selectedRecords = []
    this.oInputRilTableModel.selectedRecords.push(row)
  }

  onStatusToggleChange(event, object){
    this.textareaValue = "";
    this.selectedItem = object;
    let v = event.checked ? 1 : 0;
    if(v == 0){
      this.dialog.open(this.myDialog,{
        width: '500px'
      })
    }else{
      object["Status"] = event.checked ? 'Active' : 'De-Active';
      object["Reason_For_Deactivation"] = "";
      let passObject = { checked: event.checked ? 1 : 0, data: object };
      this.onStatusUpdate.emit(passObject);
    }
  }

  closeDialog(){
    this.selectedItem["Status"] = 'Active';
    this.dialog.closeAll();
  }

  onDeactivate(){
    this.selectedItem["Status"] = 'De-Active';
    this.selectedItem["Reason_For_Deactivation"] = this.textareaValue;
    let passObject = { checked: 0 , data: this.selectedItem };
    this.onStatusUpdate.emit(passObject);
    this.dialog.closeAll();
  }

  filteredData(data: Array<any>) {
    this._oDataSource = new MatTableDataSource(data);
    this._oDataSource.paginator = this.paginator;
    this._oDataSource.sort = this.sort;
  }

  removeInput(sText: string) {
    this.applyFilter(sText);
    (document.getElementById('nmFilter') as HTMLInputElement).value = '';
  }

  itemclickCheck(row) {
    this.onCheckBoxClick.emit(row)
  }

  onSaveColumn() {
    this.onColumnSave.emit(this.oInputRilTableModel.displayedColumns);
    this.DisplayCols.close();
  }

  trimmedValue(value: string) {
    if (value.length > 30) {
      value = value.substring(0, 30);
      value = value + "...";
    }
    return value;
  }

  getTableColumns() {
    // var obj = this.user + '_' + this.sectionCode + '_' + 'tbl';
    // this._sharedService.getRedisTable(obj).subscribe((response: any) => {
    //   if (response.data != null) {
    //     this.oInputRilTableModel.displayedColumns = response.data;
    //   }
    // }, (err) => { });
  }


  onRowAttachmentbtn(item) {
    this.onRowAttachment.emit(item);
  }


  onRefreshClick() {
    this.onRefresh.emit();
  }
  cacheSpan(array) {
    for (let i = 0; i < array.length; ) {
      const currentValueID = array[i].id;
      let arr= array.filter((item) =>{
        if(item.id === currentValueID){
          return item;
        }
      })
      const count =arr.length;
      if (!this.spans[i]) {
        this.spans[i] = {};
      }
      this.spans[i].TaxNo = count;
      i += count;
    }
  }

  getRowSpan(col, index) {    
    return this.spans[index] && this.spans[index][col];
  }

  checkDisable(){
    let res = this.perm.hasPermissionForButton(this.permObj.Preparer);
    if(res){
      return false
    }
    return true
  }

}
