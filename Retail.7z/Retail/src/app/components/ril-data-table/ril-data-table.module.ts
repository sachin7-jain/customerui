import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import {MatTableModule} from '@angular/material/table';
import { RilDataTableComponent } from './ril-data-table.component';
import {MatSelectModule} from '@angular/material/select';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { SharedModule } from 'src/app/modules/shared/shared.module';
import { PermModule } from 'src/app/modules/shared/perm.module';
import { MatRadioModule } from '@angular/material/radio';
@NgModule({
    declarations: [RilDataTableComponent],
    imports: [
        CommonModule,
        MatIconModule,
        FormsModule,
        MatCardModule,
        MatTableModule,
        MatSelectModule,
        MatSlideToggleModule,
        MatRadioModule,
        MatFormFieldModule,
        ReactiveFormsModule,
        FlexLayoutModule,
        MatInputModule,
        MatPaginatorModule,
        MatSortModule,
        PermModule,
        SharedModule
    ],
    exports: [RilDataTableComponent]
})
export class RilDataTableModule { }
