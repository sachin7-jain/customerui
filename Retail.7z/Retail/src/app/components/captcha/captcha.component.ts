import { HttpClient } from '@angular/common/http';
import { Component, ElementRef, forwardRef, Input, OnInit, ViewChild } from '@angular/core';
import { ControlValueAccessor, FormControl, NG_VALUE_ACCESSOR } from '@angular/forms';
import { Subject } from 'rxjs';
import { APIS } from 'src/app/constants/end-points';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-captcha',
  templateUrl: './captcha.component.html',
  providers: [
    {
        provide: NG_VALUE_ACCESSOR,
        useExisting: forwardRef(() => CaptchaComponent),
        multi: true
    }
],
  styleUrls: ['./captcha.component.scss']
})
export class CaptchaComponent implements OnInit, ControlValueAccessor{

//   constructor() { }

//   ngOnInit(): void {
//   }

// }
captchaCode: FormControl = new FormControl();
@ViewChild('captcha-container') captchaDiv: ElementRef;
@Input('value') val = new CaptchaObject();
@Input('urlName') urlName: string;
@Input('fullUrl') fullUrl: string;
@Input('refreshTrigger') refreshTrigger: Subject<any>;
@Input('required') required = true;
@ViewChild('captchacontainer') captchaImage;
captchaLoaded: boolean = false;
onChange: any = () => { //empty
};
onTouched: any = () => { //empty
};
get value() {
    return this.val;
}
set value(val) {
    this.val = val;
    this.onChange(val);
    this.onTouched();
}

registerOnChange(fn) {
    this.onChange = fn;
}
registerOnTouched(fn) {
    this.onTouched = fn;
}

writeValue(val) {
    this.value = new CaptchaObject();
    this.captchaCode.setValue(val ? val.captchaValue : null);
    this.getImage();

}

constructor(private http: HttpClient) { }
ngOnInit() {
    this.captchaCode.valueChanges.subscribe(val => {
        this.value = new CaptchaObject(this.value.captchaId, val);
    })
}
getInProgress = false;
getImage() {
    let completeUrl;
    if (this.getInProgress) {
        return;
    }
    if (!this.fullUrl && this.urlName) {
      console.log(environment)
        let url = environment[this.urlName];
        let endpoint = APIS.auth.captcha;
        completeUrl = `${url}${endpoint}`;
    }
    else if (this.fullUrl) {
        completeUrl = this.fullUrl;
    }
    if (completeUrl && completeUrl.length > 0) {
        this.getInProgress = true;
        this.http.get(completeUrl, { responseType: 'blob', observe: 'response' }).subscribe((res: any) => {
            this.setImage(res.body);
            this.value = new CaptchaObject(res.headers.get('ccode'), this.value.captchaValue);
            this.getInProgress = false;
        }, err => {
            console.log('Unable to get captcha!');
            this.captchaLoaded = false;
            this.getInProgress = false;
        });
    }

}
ngOnChanges() {
    this.getImage();
    if (this.refreshTrigger) {
        this.refreshTrigger.subscribe(evt => {
            this.getImage()
        })
    }
}
setImage(res) {
    this.captchaLoaded = true;
    let urlCreator = window.URL || window['webkitURL'];
    this.captchaImage.nativeElement.style.backgroundImage = `url(${urlCreator.createObjectURL(res)})`;
    this.captchaCode.setValue(null);
}
resetCaptcha() {
    this.writeValue(null);
}
}

class CaptchaObject {
captchaId: string;
captchaValue: string;
constructor(captchaId = null, captchaValue = null) {
    this.captchaId = captchaId;
    this.captchaValue = captchaValue;
}
}
