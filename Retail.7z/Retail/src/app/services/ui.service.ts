import { Injectable } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';

@Injectable({
  providedIn: 'root'
})
export class UiService {
  private appColor = '#343a40';
  private appImage = 'assets/img/logo.png';
  private appTitle = 'Transfer Pricing';
  private appDescription = 'Transfer Pricing';
  constructor(private meta: Meta, private title: Title) { }

  public  setMetaData(config?) {
    if (!config)
      config = {};
    const appColor = config.appColor || this.appColor;
    const description = config.description || this.appDescription;
    const image = config.image || this.appImage;
    const title = config.header
      ? `${config.header}`
      : this.appTitle;
    this.title.setTitle(title)
    const tags = [
      { name: 'description', content: description },
      { name: 'theme-color', content: appColor },
      { name: 'twitter:card', content: 'summary' },
      { name: 'twitter:image', content: image },
      { name: 'twitter:title', content: title },
      { name: 'twitter:description', content: description },
      { name: 'apple-mobile-web-app-capable', content: 'yes' },
      { name: 'apple-mobile-web-app-status-bar-style', content: 'black-translucent' },
      { name: 'apple-mobile-web-app-title', content: title },
      { name: 'apple-touch-startup-image', content: image },
      { property: 'og:title', content: title },
      { property: 'og:description', content: description },
      { property: 'og:image', content: image },
    ];
    tags.forEach(tag => this.meta.updateTag(tag));
  }

  getTitle(){
    return this.appTitle;
  }
}
