import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { APIS, BASEURLS } from '../constants/end-points';
import { CookieService } from './cookie.service';
@Injectable({
    providedIn: 'root'
})
export class Wso2Service {
    constructor(private http: HttpClient, private cookie: CookieService) { }

    fetchTokenAndSave() {
        this.tokenApi('fetch').subscribe((res:any) => {
            this.saveBothTokens(res);
        });
    }
    fetchToken(){
        return this.tokenApi('fetch');
    }
    refreshToken(){
        return this.tokenApi('refresh');
    }

    tokenApi(mode: 'fetch' | 'refresh') {
        let endpoint = mode === 'fetch' ? APIS.auth.token : APIS.auth.refreshToken;
        let url = environment[BASEURLS.AUTH];
        let headObj = {
            'applicationCode': environment['applicationCode'],
            'Content-Type': 'application/json',
        };
        if (mode === 'refresh')
            headObj['refresh-token'] = this.getToken("refresh");
        let headers: HttpHeaders = new HttpHeaders(headObj);
        return this.http.get(url + endpoint, { headers: headers, withCredentials: true })
    }

    getToken(type: 'fetch' | 'refresh') {
        switch (type) {
            case 'fetch':
                try {
                    return this.cookie.get('fetchToken');
                } catch (e) {
                    return '';
                }
            case 'refresh':
                try {
                    return this.cookie.get('refreshToken');
                } catch (e) {
                    return '';
                }
            default:
                return '';
        }
    }

    saveBothTokens(data){
        this.saveToken('fetch', data.access_token);
        this.saveToken('refresh', data.refresh_token);
    }
    clearTokens(){
        this.cookie.delete('fetchToken');
        this.cookie.delete('refreshToken');
    }
    saveToken(type: 'fetch' | 'refresh', token) {
        this.cookie.set(`${type}Token`, token, undefined, '/', undefined, undefined, "Strict");
    }
}