import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { catchError, switchMap, tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { AuthService } from '../auth.service';
import { Wso2Service } from '../wso2.service';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
    constructor(private wso2: Wso2Service, private auth: AuthService) { }
    private _refreshSubject: Subject<any> = new Subject<any>();
    intercept(
        req: HttpRequest<any>,
        next: HttpHandler
    ): Observable<any> {
        if (!environment.isWSO2 || req.url.indexOf('fetchToken') !== -1 || req.url.indexOf('refreshToken') !== -1 || req.url.indexOf('logout') !== -1)
            return next.handle(req).pipe(
                catchError((error) => {
                    if (error instanceof HttpErrorResponse) {
                        if (error.error && error.error.OPStatus && error.error.OPStatus.Message === 'MYSSO has expired') {
                            if (req.url.indexOf('logout') === -1)
                                this.auth.logout();
                        }
                    }
                    throw error;
                })
            );
        else
            return next.handle(req).pipe(
                catchError((error) => {
                    if (error instanceof HttpErrorResponse) {
                        if (error.status === 401 && this.checkAccessFail(error.error)) {
                            return this._ifTokenExpired().pipe(
                                switchMap(() => {
                                    return next.handle(this.updateHeader(req));
                                })
                            );
                        }
                    }
                    throw error;
                })
            )
    }


    updateHeader(req) {
        const authToken = this.wso2.getToken('fetch');
        req = req.clone({
            headers: req.headers.set("Authorization", `Bearer ${authToken}`)
        });
        return req;
    }
    _ifTokenExpired(): Observable<HttpEvent<any>> {
        this._refreshSubject.subscribe({
            complete: () => {
                this._refreshSubject = new Subject<any>();
            },
            error: () => {
                this._refreshSubject = new Subject<any>();
            }
        });
        if (this._refreshSubject.observers.length === 1) {
            this.wso2.refreshToken().pipe(
                tap(res => {
                    this.wso2.saveBothTokens(res);
                }),
                catchError(err => {
                    throw err;
                })

            ).subscribe(this._refreshSubject);
        }
        return this._refreshSubject;
    }
    checkAccessFail(res) {
        //todo
        if (res.message && res.message.indexOf('You are unauthorized to do this action') !== -1) {
            return false;
        }
        return true;
    }
}