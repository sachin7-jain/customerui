import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';

@Injectable()
export class LoaderInterceptor implements HttpInterceptor {

  constructor() { }
  count = 0;
  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    if((request.url.includes('loc-by-ip')) || (request.url.includes('uploadARfile'))){
      return next.handle(request).pipe(
        finalize(() => {})
      );
    }else{
      this.increase();
      return next.handle(request).pipe(
        finalize(() => this.decrease())
      );
    }
  }
  increase() {
    this.count++;
    document.getElementById('loader').className = "visible-loader";
  }
  decrease() {
    this.count--;
    if (this.count === 0) {
      document.getElementById('loader').className = "hidden-loader";
    }
  }
}
