import { HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, ReplaySubject } from 'rxjs';
import { environment } from 'src/environments/environment';
import { LOGIN } from '../constants/const';
import { APIS, BASEURLS } from '../constants/end-points';
import { CookieService } from './cookie.service';
import { SharedHttpService } from './http.service';
import { StateService } from './state.service';
import { Wso2Service } from './wso2.service';
@Injectable({
    providedIn: 'root'
})
export class AuthService {
    constructor(private state: StateService, private http: SharedHttpService, private wso2: Wso2Service, private cookie: CookieService, private router: Router) { }

    isLoggedIn: boolean = false;
    userSub: BehaviorSubject<any> = new BehaviorSubject({});
    login(obj): Observable<any> {
        let result: ReplaySubject<any> = new ReplaySubject();
        
        this.http.post(BASEURLS.AUTH, APIS.auth.captchlogin, obj).subscribe((res: any) => {
            // if (environment.local) {
                this.saveLocalData(res.data);
            // }
            this.loginWithCookie().subscribe(data => {
                result.next(data);
            }, err => {
                result.error(err);
            });
        }, err => {
            result.error(err);
        })
        return result.asObservable();
    }

    loginWithCookie(): Observable<any> {
        let result: ReplaySubject<any> = new ReplaySubject();
        let userData = this.getUser();
        if (userData) {
            if (environment.isWSO2) {
                this.wso2.fetchToken().subscribe(data => {
                    this.wso2.saveBothTokens(data);
                    this.saveLoginData(userData);
                    result.next(userData);
                    this.isLoggedIn = true;
                }, err => {
                    this.cookie.delete('USER', '/', '.ril.com')
                    this.cookie.delete('USER', '/')
                    result.error(err);
                });
            }
            else {
                this.saveLoginData(userData);
                result.next(userData);
                this.isLoggedIn = true;
            }
        }
        else {
            result.error('Cookie not available');
        }
        return result.asObservable();
    }

    logout(path?) {
        let result: ReplaySubject<any> = new ReplaySubject();
        let headObj = {
            'applicationCode': environment['applicationCode'] || '',
            'Content-Type': 'application/json',
            'refresh-token': this.wso2.getToken('refresh') || ''
        };
        this.http.get(BASEURLS.AUTH, APIS.auth.logout, { headers: headObj }).subscribe((success: any) => {
            result.next(true);
            this.clearLoginData();
            this.router.navigateByUrl(path || LOGIN);
        }, err => {
            console.warn(err);
            result.next(false);
            this.clearLoginData();
            this.router.navigateByUrl(path || LOGIN);
        })
        return result;
    }

    isAuthorized() {
        return this.checkCookieValid();
    }

    checkCookieValid() {
        let userCookie: any = this.getUser();
        let backupCookie: any = decodeURIComponent(this.cookie.get('USERINFO'));
        if (!(backupCookie && backupCookie.length > 0)) {
            if (userCookie) {
                return true;
            }
            else {
                return false;
            }
        }
        backupCookie = JSON.parse(backupCookie);
        if (userCookie.domain === backupCookie.domain && userCookie !== 'undefined') {
            try {
                if (userCookie.env === environment.env || environment.local) {
                    return true;
                }
                else {
                    return false;
                }
            }
            catch (e) {
                return false;
            }
        }
        return false;
    }

    saveLoginData(data) {
        this.userSub.next(data);
        this.cookie.set(`USERINFO`, JSON.stringify(data), undefined, '/', undefined, undefined, "Strict");
    }
    saveLocalData(data) {
        this.cookie.set(`USER`, JSON.stringify(data), undefined, '/', undefined, undefined, "Strict");
    }

    getUser() {
        if(this.cookie.get('USER')!== 'undefined'){
            try {
                let u = JSON.parse(decodeURIComponent(this.cookie.get('USER')));
                return {
                    domain: u.domain || u.domain_id, 
                    employeeName: u.employeeName || u.fullname, 
                    emailID: u.emailID || u.email,
                    // env: u.env
                }
            }
            catch (e) {
                return null;
            }
        }
        // try {
        //     let u = JSON.parse(decodeURIComponent(this.cookie.get('USER')));
        //     return {
        //         domain: u.domain || u.domain_id,
        //         employeeName: u.employeeName || u.fullname,
        //         emailID: u.emailID || u.email
        //     }
        // }
        // catch (e) {
        //     return null;
        // }
    }

    getUserId() {
        try {
            let cookie = JSON.parse(decodeURIComponent(this.cookie.get('USER')));
            return cookie.domain_id || cookie.domain
        }
        catch (e) {
            return null;
        }
    }

    getUserSub() {
        let user = this.getUser();
        if (user) {
            this.userSub.next(user);
        }
        return this.userSub.asObservable();
    }

    clearLoginData() {
        this.wso2.clearTokens();
        this.cookie.delete('state', '/');
        this.cookie.delete('raccess', '/');
        this.cookie.delete('USERINFO', '/');
        this.cookie.delete('USER', '/', '.ril.com')
        this.cookie.delete('USER', '/')
        this.cookie.delete('masterARData', '/')
    }

}