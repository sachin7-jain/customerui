import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { PermissionService } from './perm.service';
@Injectable()
export class AppInitService {
    constructor(private httpClient: HttpClient, private perm: PermissionService) {
    }
    init(): Promise<any> {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                resolve();
            }, 500);
        });
    }
    loadUrls(): Promise<any> {
        return new Promise((resolve, reject) => {
            this.httpClient.get('./assets/config/environment.json').subscribe(env => {
                Object.keys(env).forEach(key => {
                    if(env[key])
                        environment[key] = env[key]
                })
                this.perm.getPermissions().subscribe((res:any) => {
                    resolve();
                }, err => {
                    resolve();
                })
            }, err => {
                reject();
            })  
        })
    }
}