import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { environment } from 'src/environments/environment';
@Injectable({
    providedIn: 'root'
})
export class NotifyService {
    constructor(private ms: MatSnackBar) { }
    private defaultMsg = 'Something went wrong';
    errorMessage(error: any, defaultMsg?: string, duration = 5000) {
        if (!environment.production)
             //console.log(error);
        if (typeof error !== 'string' && error && error.error && error.error.Message) {
            defaultMsg = error.error.Message;
        }
        else if (typeof error !== 'string' && error && error.error && error.error.OPStatus && error.error.OPStatus.Message) {
            defaultMsg = error.error.OPStatus.Message;
        }
        else if (typeof error === 'string') {
            defaultMsg = error;
        }
        this.ms.open(defaultMsg || this.defaultMsg, null, {
            duration: duration,
            panelClass: 'error-snackbar'
        })
    }

    successMessage(msg: string, duration = 5000) {
        this.ms.open(msg, null, {
            duration: duration,
            panelClass: 'success-snackbar'
        })
    }
}