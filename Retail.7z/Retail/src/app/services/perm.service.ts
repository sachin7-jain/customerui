import { Injectable } from '@angular/core';
import { ReplaySubject, Subject } from 'rxjs';
import { environment } from 'src/environments/environment';
import { APIS, BASEURLS } from '../constants/end-points';
import { AuthService } from './auth.service';
import { CookieService } from './cookie.service';
import { SharedHttpService } from './http.service';

@Injectable({
  providedIn: 'root'
})
export class PermissionService {

  constructor(private cookie: CookieService, private http: SharedHttpService, private authsvc: AuthService) { }
  DEFAULT = false;
  auth = {
    S_PCODE: this.DEFAULT,
    ETM_MST: this.DEFAULT,
    AE_MST: this.DEFAULT,
    SUM_MST: this.DEFAULT,
    ETM_SUP: this.DEFAULT,
    AR_UPLD: this.DEFAULT,
    BUS_REC: this.DEFAULT,
    REVW_TP: this.DEFAULT,
    TRAN_SM: this.DEFAULT,
    MIS: this.DEFAULT
  };
  pcodes = {
    FA22001: this.DEFAULT,
    FA22002: this.DEFAULT,
    FA22003: this.DEFAULT
  };
  fetchstatus = false;

  codeMap = {
    '01': 'Preparer',
    '02': 'Display',
    '03': 'ReviewVerify',
    '04': 'ReValidate',
    '05': 'Approve',
  }

  actvt = {
    Preparer: this.DEFAULT,
    Display: this.DEFAULT,
    ReviewVerify: this.DEFAULT,
    ReValidate: this.DEFAULT,
    Approve: this.DEFAULT
  }

  ETM_MST={
    PrivilegeCode:this.DEFAULT,
    CompanyCode:this.DEFAULT,
    Division:this.DEFAULT
  }

  AE_MST={
    PrivilegeCode:this.DEFAULT,
    CompanyCode:this.DEFAULT,
    Division:this.DEFAULT
  }

  SUM_MST={
    PrivilegeCode:this.DEFAULT,
    CompanyCode:this.DEFAULT,
    Division:this.DEFAULT
  }

  ETM_SUP={
    PrivilegeCode:this.DEFAULT,
    CompanyCode:this.DEFAULT,
    Division:this.DEFAULT
  }

  BUS_REC = {
    PrivilegeCode:this.DEFAULT,
    CompanyCode:this.DEFAULT,
    Division:this.DEFAULT
  }

  REVW_TP= {
    PrivilegeCode:this.DEFAULT,
    CompanyCode:this.DEFAULT,
    Division:this.DEFAULT
  }

  TRAN_SM= {
    PrivilegeCode:this.DEFAULT,
    CompanyCode:this.DEFAULT,
    Division:this.DEFAULT
  }

  MIS= {
    PrivilegeCode:this.DEFAULT,
    CompanyCode:this.DEFAULT,
    Division:this.DEFAULT
  }



  ccode = [];

  loadPermission() {
    const promise = this.getPermissions()
      .toPromise();
    return promise;
  }
  getPermissions() {
    this.auth = {
      S_PCODE: this.DEFAULT,
      ETM_MST: this.DEFAULT,
      AE_MST: this.DEFAULT,
      SUM_MST: this.DEFAULT,
      ETM_SUP: this.DEFAULT,
      AR_UPLD: this.DEFAULT,
      BUS_REC: this.DEFAULT,
      REVW_TP: this.DEFAULT,
      TRAN_SM: this.DEFAULT,
      MIS: this.DEFAULT
    };
    let sub: ReplaySubject<boolean> = new ReplaySubject();
    if (!this.authsvc.isAuthorized()) {
      sub.next(false);
      return sub;
    }
    let data: any = this.cookie.get('raccess');
    if (!(data && data.length > 0))
      this.fetchstatus = false;
    if (!this.fetchstatus) {
      this.http.post(BASEURLS.BASE, APIS.access.getallauth, {
        "appl_id": environment.appAccessId,
        // "user_id": this.authsvc.getUserId()
      }).subscribe((res: any) => {
        // console.log(res);
        this.fetchstatus = true;
        res.data.auth_obj_values.forEach(ob => {
          switch (ob.auth_obj) {
            case 'S_PCODE':
              this.auth.S_PCODE = true;
              this.pcodes[ob.value01.trim()] = true;
              break;
            case 'ETM_MST':
              this.auth.ETM_MST = true;
              ob.value01.trim().split(',').forEach(r => {
                this.actvt[this.codeMap[r]] = true;
              })
              this.ETM_MST.PrivilegeCode=this.bindRole1(this.ETM_MST,'PrivilegeCode',ob.value01);
              this.ETM_MST.CompanyCode=this.bindRole(this.ETM_MST,'CompanyCode',ob.value02);
              this.ETM_MST.Division=this.bindRole(this.ETM_MST,'Division',ob.value03);     
              break;
            case 'AE_MST':
              this.auth.AE_MST = true;
              ob.value01.trim().split(',').forEach(r => {
                this.actvt[this.codeMap[r]] = true;
              })
              ob.value02.trim().split(',').forEach(r=>{
                this.ccode.push(r);
              })
              this.AE_MST.PrivilegeCode=this.bindRole1(this.AE_MST,'PrivilegeCode',ob.value01);
              this.AE_MST.CompanyCode=this.bindRole(this.AE_MST,'CompanyCode',ob.value02);
              this.AE_MST.Division=this.bindRole(this.AE_MST,'Division',ob.value03);
              break;
            case 'SUM_MST':
              this.auth.SUM_MST = true;
              ob.value01.trim().split(',').forEach(r => {
                this.actvt[this.codeMap[r]] = true;
              })
              this.SUM_MST.PrivilegeCode=this.bindRole1(this.SUM_MST,'PrivilegeCode',ob.value01);
              this.SUM_MST.CompanyCode=this.bindRole(this.SUM_MST,'CompanyCode',ob.value02);
              this.SUM_MST.Division=this.bindRole(this.SUM_MST,'Division',ob.value03);
              break;
            case 'ETM_SUP':
              this.auth.ETM_SUP = true;
              ob.value01.trim().split(',').forEach(r => {
                this.actvt[this.codeMap[r]] = true;
              })
              this.ETM_SUP.PrivilegeCode=this.bindRole1(this.ETM_SUP,'PrivilegeCode',ob.value01);
              this.ETM_SUP.CompanyCode=this.bindRole(this.ETM_SUP,'CompanyCode',ob.value02);
              this.ETM_SUP.Division=this.bindRole(this.ETM_SUP,'Division',ob.value03);
              break;
            case 'AR_UPLD':
              this.auth.AR_UPLD = true;
              ob.value01.trim().split(',').forEach(r => {
                this.actvt[this.codeMap[r]] = true;
              })
              break;
            case 'BUS_REC':
              this.auth.BUS_REC = true;
              ob.value01.trim().split(',').forEach(r => {
                this.actvt[this.codeMap[r]] = true;
              })
              this.BUS_REC.PrivilegeCode=this.bindRole1(this.BUS_REC,'PrivilegeCode',ob.value01);
              this.BUS_REC.CompanyCode=this.bindRole(this.BUS_REC,'CompanyCode',ob.value02);
              this.BUS_REC.Division=this.bindRole(this.BUS_REC,'Division',ob.value03);
              break;
            case 'REVW_TP':
              this.auth.REVW_TP = true;
              ob.value01.trim().split(',').forEach(r => {
                this.actvt[this.codeMap[r]] = true;
                this.REVW_TP.PrivilegeCode=this.bindRole1(this.REVW_TP,'PrivilegeCode',ob.value01);
                this.REVW_TP.CompanyCode=this.bindRole(this.REVW_TP,'CompanyCode',ob.value02);
                this.REVW_TP.Division=this.bindRole(this.REVW_TP,'Division',ob.value03);
              })
              break;
            case 'TRAN_SM':
              this.auth.TRAN_SM = true;
              ob.value01.trim().split(',').forEach(r => {
                this.actvt[this.codeMap[r]] = true;
                this.TRAN_SM.PrivilegeCode=this.bindRole1(this.TRAN_SM,'PrivilegeCode',ob.value01);
                this.TRAN_SM.CompanyCode=this.bindRole(this.TRAN_SM,'CompanyCode',ob.value02);
                this.TRAN_SM.Division=this.bindRole(this.TRAN_SM,'Division',ob.value03);
              })
              break;
            case 'MIS':
              this.auth.MIS = true;
              ob.value01.trim().split(',').forEach(r => {
                this.actvt[this.codeMap[r]] = true;
              })
              this.MIS.PrivilegeCode=this.bindRole1(this.MIS,'PrivilegeCode',ob.value01);
              this.MIS.CompanyCode=this.bindRole(this.MIS,'CompanyCode',ob.value02);
              this.MIS.Division=this.bindRole(this.MIS,'Division',ob.value03);
              break;

          }
        });
        this.cookie.set('raccess', JSON.stringify({
          pcodes: this.pcodes,
          auth: this.auth,
          actvt: this.actvt,
          ccode: this.ccode
        }), undefined, '/', undefined, undefined, "Strict");
        sub.next(true);
      }, err => {
        sub.next(false);
        this.cookie.delete('raccess', '/');
      })
    }
    else {
      data = JSON.parse(data);
      this.fetchstatus = true;
      this.pcodes = data.pcodes;
      this.auth = data.auth;
      this.actvt = data.actvt;
      sub.next(true);
    }
    return sub.asObservable();
  }

  hasPermission(ob: PermissionReq[]) {
    let result: ReplaySubject<any> = new ReplaySubject();
    this.getPermissions().subscribe(v => {
      if (v) {
        for (let o of ob) {
          if (!this.processConditionOb(o)) {
            result.next(false);
            return;
          }
        }
        result.next(true);
      }
    })
    result.next(true);
    return result.asObservable();
  }

  hasPermissionSync(ob: PermissionReq[]) {
    if (ob.length === 0)
      return true;
    for (let o of ob) {
      if (this.processConditionOb(o)) {
        return true;
      }
    }
    return false;
  }

  hasPermissionForButton(obj: any[]){
    if(obj.length == 0){
      return true;
    }
    for(let el of obj){
      if(this.processCondBtn(el)){
        return true;
      }
    }
    return false;
  }

  processCondBtn(obj: PermissionReq){
    let data =  this[obj.ob]?.PrivilegeCode;
    if(data && data[obj.actvt]){
      return true
    }
    return false;
  }

  processConditionOb(ob: PermissionReq) {
    for (let key of Object.keys(ob)) {
      switch (key) {
        case 'ob':
          if (!this.auth[ob[key]])
            return false;
          break;
        case 'code':
          if (!this.pcodes[ob[key]])
            return false;
          break;
        case 'actvt':
          if (!this.actvt[ob[key]])
            return false;
          break;
      }
    }
    return true;
  }

  clearPermission() {
    this.fetchstatus = false;
    this.cookie.delete('raccess', '/');
  }

  bindRole(object,key,values){
    // console.log(values);
    
    let roleArray=object[key]?object[key].split(','):[];
    roleArray.push(...values.split(','));
    return roleArray.filter((v,i,a)=>a.indexOf(v)===i).join(',');
  }

  bindRole1(obj,key,value){
    let roleArray=obj[key]?obj[key]:[];
    value.trim().split(',').forEach(r => {
      roleArray[this.codeMap[r]] = true;
    })
    return roleArray;
  }
}

export class PermissionReq {
  ob?: string;
  code?: string;
  actvt?: 'Preparer' | 'Display' | 'ReviewVerify' | 'ReValidate' | 'Approve';
}