import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { CookieService } from './cookie.service';
import { InterceptorSkipHeader } from '../constants/const';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class SharedHttpService {

    headers = {};
    private globalOptions: any = {
        'Content-Type': 'application/json',
        withCredentials: true
    };
    private _apiUrl = environment['apiURL'];
    constructor(
        private _http: HttpClient,
        private cookie: CookieService) {
    }

    get<T>(url:string, endpoint:string, config: RequestConfigModel = new RequestConfigModel()):Observable<T> {
        url = this.getUrl(url);
        const queryString = config.queryParams ? this._objectToQueryString(config.queryParams) : '';
        endpoint = endpoint + (queryString ? '?' + queryString : '');
        if(!config.headers){
            config.headers = {};
        }
        if(environment.isWSO2 || config.wso2){
            config.headers['Authorization'] = 'Bearer ' + this.getAccessToken(); 
        }
        if(!config.loader){
            config.headers[InterceptorSkipHeader] = "-";
        }
        let head: HttpHeaders = new HttpHeaders(config.headers);
        let options = Object.assign({}, this.globalOptions);
        if(config.creds === false){
            options['withCredentials'] = false;
        }
        if(config.observe){
            options['observe'] = config.observe;
        }
        if(config.responseType){
            options['responseType'] = config.responseType;
        }
        options['headers'] = head;
        return this._http.get<T>(url + endpoint + (config.urlParam?config.urlParam:''), <Object>options);
    }

    getFileDownload<T>(url:string, endpoint:string, data: any, config: RequestConfigModel = new RequestConfigModel()):Observable<T> {
        url = this.getUrl(url);
        const queryString = config.queryParams ? this._objectToQueryString(config.queryParams) : '';
        endpoint = endpoint + (queryString ? '?' + queryString : '');
        if(!config.headers){
            config.headers = {};
        }
        if(environment.isWSO2 || config.wso2){
            config.headers['Authorization'] = 'Bearer ' + this.getAccessToken(); 
        }
        if(!config.loader){
            config.headers[InterceptorSkipHeader] = "-";
        }
        let head: HttpHeaders = new HttpHeaders(config.headers);
        let options = Object.assign({}, this.globalOptions);
        if(config.creds === false){
            options['withCredentials'] = false;
        }
        if(config.observe){
            options['observe'] = config.observe;
        }
        if(config.responseType){
            options['responseType'] = config.responseType;
        }
        options['headers'] = head;
        return this._http.get<T>(url + endpoint + (config.urlParam?config.urlParam:''), <Object>options);
    }

    getWSO2FileDownload(url, endpoint, params, headObject = {}) {
        headObject['Content-Type']='application/json';
        headObject['Authorization']='Bearer ' + this.getAccessToken();
        let headers = new HttpHeaders(headObject);
        const that = this;
        that.setApiUrl(url);
        const queryString = params ? that._objectToQueryString(params) : '';
        endpoint = endpoint + (queryString ? '?' + queryString : '');
        return that._http.get(that._apiUrl + endpoint, { headers: headers, withCredentials: false,  responseType: 'blob'  });
      }
    post<T>(url:string, endpoint:string, data: any, config: RequestConfigModel = new RequestConfigModel()): Observable<T> {
        url = this.getUrl(url);
        const queryString = config.queryParams ? this._objectToQueryString(config.queryParams) : '';
        endpoint = endpoint + (queryString ? '?' + queryString : '');
        if(!config.headers){
            config.headers = {};
        }
        if(environment.isWSO2 || config.wso2){
            config.headers['Authorization'] = 'Bearer ' + this.getAccessToken(); 
        }
        if(!config.loader){
            config.headers[InterceptorSkipHeader] = "-";
        }
        let head: HttpHeaders = new HttpHeaders(config.headers);
        let options = Object.assign({}, this.globalOptions);
        if(config.creds === false){
            options['withCredentials'] = false;
        }
        if(config.observe){
            options['observe'] = config.observe;
        }
        if(config.responseType){
            options['responseType'] = config.responseType;
        }
        options['headers'] = head;
        return this._http.post<T>(url + endpoint + (config.urlParam?config.urlParam:''), data, <Object>options);
    }

    put<T>(url:string, endpoint:string, data: any, config: RequestConfigModel = new RequestConfigModel()): Observable<T> {
        url = this.getUrl(url);
        const queryString = config.queryParams ? this._objectToQueryString(config.queryParams) : '';
        endpoint = endpoint + (queryString ? '?' + queryString : '');
        if(!config.headers){
            config.headers = {};
        }
        if(environment.isWSO2 || config.wso2){
            config.headers['Authorization'] = 'Bearer ' + this.getAccessToken(); 
        }
        if(!config.loader){
            config.headers[InterceptorSkipHeader] = "-";
        }
        let head: HttpHeaders = new HttpHeaders(config.headers);
        let options = Object.assign({}, this.globalOptions);
        if(config.creds === false){
            options['withCredentials'] = false;
        }
        if(config.observe){
            options['observe'] = config.observe;
        }
        if(config.responseType){
            options['responseType'] = config.responseType;
        }
        options['headers'] = head;
        return this._http.put<T>(url + endpoint + (config.urlParam?config.urlParam:''), data, <Object>options)
    }

    delete<T>(url:string, endpoint:string, data: any, config: RequestConfigModel = new RequestConfigModel()): Observable<T> {
        url = this.getUrl(url);
        const queryString = config.queryParams ? this._objectToQueryString(config.queryParams) : '';
        endpoint = endpoint + (queryString ? '?' + queryString : '');
        if(!config.headers){
            config.headers = {};
        }
        if(environment.isWSO2 || config.wso2){
            config.headers['Authorization'] = 'Bearer ' + this.getAccessToken(); 
        }
        if(!config.loader){
            config.headers[InterceptorSkipHeader] = "-";
        }
        let head: HttpHeaders = new HttpHeaders(config.headers);
        let options = Object.assign({}, this.globalOptions);
        if(config.creds === false){
            options['withCredentials'] = false;
        }
        if(config.observe){
            options['observe'] = config.observe;
        }
        if(config.responseType){
            options['responseType'] = config.responseType;
        }
        options['headers'] = head;
        return this._http.post<T>(url + endpoint + (config.urlParam?config.urlParam:''), data, <Object>options)
    }

    patch<T>(url:string, endpoint:string, data: any, config: RequestConfigModel = new RequestConfigModel()): Observable<T> {
        url = this.getUrl(url);
        const queryString = config.queryParams ? this._objectToQueryString(config.queryParams) : '';
        endpoint = endpoint + (queryString ? '?' + queryString : '');
        if(!config.headers){
            config.headers = {};
        }
        if(environment.isWSO2 || config.wso2){
            config.headers['Authorization'] = 'Bearer ' + this.getAccessToken(); 
        }
        if(!config.loader){
            config.headers[InterceptorSkipHeader] = "-";
        }
        let head: HttpHeaders = new HttpHeaders(config.headers);
        let options = Object.assign({}, this.globalOptions);
        if(config.creds === false){
            options['withCredentials'] = false;
        }
        if(config.observe){
            options['observe'] = config.observe;
        }
        if(config.responseType){
            options['responseType'] = config.responseType;
        }
        options['headers'] = head;
        return this._http.patch<T>(url + endpoint + (config.urlParam?config.urlParam:''), data, <Object>options);
    }

    private _objectToQueryString(object) {
        return Object
            .keys(object)
            .map(key => `${encodeURIComponent(key)}=${encodeURIComponent(object[key])}`)
            .join('&');
    }

    private getUrl(url){
        return environment[url];
    }

    setApiUrl(url) {
        const that = this;
        that._apiUrl = environment[url];
      }

    private getAccessToken() {
        try {
            return this.cookie.get('fetchToken');
        } catch (e) {
            return '';
        }
    }
}

class RequestConfigModel {
    queryParams?:any = null;
    urlParam?:string = '';
    headers?:any = {};
    loader?:boolean = true;
    creds?:boolean= true;
    observe?: 'response'|'body';
    responseType?: 'json' | 'blob';
    wso2?:boolean = false;
}