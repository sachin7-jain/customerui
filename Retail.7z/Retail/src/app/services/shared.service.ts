import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { APIS, BASEURLS } from '../constants/end-points';
import { getDTFFN } from '../function/date-format';
import { SharedHttpService } from './http.service';
import { NotifyService } from './notify.service';
@Injectable()
export class SharedService {
    constructor(
        private _snackBar: MatSnackBar,
        private _httpService: SharedHttpService,
        private _notyService: NotifyService
    ) {}
   
    get httpService() {
        return this._httpService;
    }
    openSnackBar(message: string, action?: string) {
        this._snackBar.open(message, action, {
            duration: 3000,
        });
    }

    closeSnackBar() {
        this._snackBar.dismiss();
    }
    downloadExcelFile(filename: string, exportData: Array<any>, exportHeader: Array<any>) {
        let newExHead: Array<any> = [];
        exportHeader.forEach((v: any) => {
            if (!(v.json_key.toLowerCase() == 'isdelete' || v.json_key.toLowerCase() == 'view' || v.json_key.toLowerCase() == 'action')) {
                newExHead.push(v);
            }
        });
        let data: any = {
            data: exportData,
            json: {
                table: "Data",
                columns: newExHead
            }
        }
        this.httpService.post(BASEURLS.BASE,APIS.FILE_API.exportToExcel, data)
            .subscribe((response: any) => {
                let downloadData = response.file_base64;
                const linkSource = `data:application/vnd.ms-excel;base64,${downloadData}`;
                const downloadLink = document.createElement("a");
                const fileName = `${filename}_DATA_${getDTFFN()}.xlsx`;
                downloadLink.href = linkSource;
                downloadLink.download = fileName;
                downloadLink.click();
            }, (error) => {
                this._notyService.errorMessage(error);
            });
    }
}