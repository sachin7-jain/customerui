import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { CookieService } from './cookie.service';

@Injectable({
    providedIn: 'root'
})
export class StateService {
    private state: any = {};
    private stateSub: BehaviorSubject<any> = new BehaviorSubject({});

    constructor(private cookie: CookieService) {
        this.loadState();
     }

    loadState(){
        let state = this.cookie.get('state');
        if(state){
            this.state = JSON.parse(state);
            this.stateSub.next(this.state);
        }
    }

    clearState(){
        this.cookie.delete('state');
    }

    setKey(key, value) {
        this.state[key] = value;
        this.changeState();
    }

    removeKey(key){
        delete this.state[key];
        this.changeState();
    }
    setObject(obj) {
        this.state = {
            ...this.state,
            ...obj
        }
        this.changeState();
    }

    getState(key) {
        return this.stateSub.asObservable().pipe(
            map(r => {
                return r[key];
            })
        );
    }

    getStateValue(key) {
        return this.state[key];
    }

    private changeState(){
        this.cookie.set('state', JSON.stringify(this.state), undefined, '/', undefined, undefined, "Strict");
        this.stateSub.next(this.state);
    }
}