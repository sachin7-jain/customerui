export function getDTFFN(): string { //get date time seconds for filename
    let now = new Date();
    let timestamp = now.getFullYear().toString();
    let month = now.getMonth() + 1;
    timestamp += (month < 10 ? '0' : '') + month.toString();
    timestamp += (now.getDate() < 10 ? '0' : '') + now.getDate().toString();
    timestamp += '-'
    timestamp += (now.getHours() < 10 ? '0' : '') + now.getHours().toString();
    timestamp += (now.getMinutes() < 10 ? '0' : '') + now.getMinutes().toString();
    timestamp += '-'
    timestamp += (now.getSeconds() < 10 ? '0' : '') + now.getSeconds().toString();
    timestamp += (now.getMilliseconds() < 100 ? '0' : '') + now.getMilliseconds().toString();
    return timestamp;
}