export const menu = [
    {
        path: 'login_form',
        loadChildren: () => import('../modules/main/main/transfer-pricing/transfer-pricing.module').then(m => m.TransferPricingModule),
        data: {
            title: 'login_form',
            header: 'Login Form',
            route: 'login_form',
            img: 'assets/images/Group 126668.svg',
            height: "30",
            width: "30",
            alt: 'Login Form',
            children: [
                
                {
                    title: 'summary',
                    header: 'Transaction Summary',
                    route: 'login_form/summary',
                    img: 'assets/images/Group 119615.svg',
                    alt: "Transaction Summary",
                }
            ]
        }
    }
]