import { environment } from 'src/environments/environment'
const TRPCMasters = (environment.isWSO2 ? 'FMS_TRPC_NJ_Masters/1.0.0/' : 'trpc/masters/');
const TRPC = (environment.isWSO2 ? 'FMS_TRPC_NJ_TransferPricing/1.0.0/' : 'trpc/transaction/');
export const APIS = {
    auth: {
        token: 'gentoken/fetchToken',
        refreshToken: 'gentoken/refreshToken',
        login: 'login',
        logout: 'logout',
        captcha: 'captchaSrv/captcha',
        captchlogin: "loginSrv/login"
    },
    access: {
        get: 'CE_NODE_AC/1.0.0/api/getauth',
        check: 'CE_NODE_AC/1.0.0/api/checkauth',
        getall: 'CE_NODE_AC/1.0.0/api/getallauth',
        getallauth: 'FMS_NJ_UserMgmt/1.0.0/user/getAllAuth',
    },
    AE_MASTER:{
        'get':TRPCMasters+"associate-enterprise-master/get",
        'manage':TRPCMasters+"associate-enterprise-master/manage",
        'nature_relationship':TRPCMasters+"associate-enterprise-master/fetch-nature-of-relationships",
        'inactivate':TRPCMasters+"associate-enterprise-master/inactivate"
    },
    Entity_Transactio_MASTER:{
        'getmatchedata':TRPCMasters+"entityMasters/getmatchedata",
        'getunmatchedata':TRPCMasters+"entityMasters/getunmatchedata",
        'fetchae':TRPCMasters+"entityMasters/fetchae",
        'fetchoffsetgl':TRPCMasters+"entityMasters/fetchoffsetgl",
        'fetchsupplement':TRPCMasters+"entityMasters/fetchsupplement",
        'addnewrecord':TRPCMasters+"entityMasters/manage/addnewrecord",
        'editrecords':TRPCMasters+"entityMasters/manage/editrecords",
        'deleterecord':TRPCMasters+"entityMasters/deleterecord",
        'verify':TRPCMasters+"entityMasters/verify",
        'movetomatch':TRPCMasters+"entityMasters/movetomatch"
    },
    SUPPLEMENT_MASTER:{
        'get':TRPCMasters+"supplement-master/get",
        'manage':TRPCMasters+"supplement-master/manage",
        'inactivate':TRPCMasters+"supplement-master/inactivate"

    },
    Segment_Master:{
        getData: TRPCMasters+"segmentMasters/getdata",
        fetchSegment: TRPCMasters+"segmentMasters/fetchsegments",
        save: TRPCMasters+"segmentMasters/addnewuser",
        updateStatus: TRPCMasters+"segmentMasters/updateActivestatus",
    },
    USER_API: {
        getUserInfo: "CU_NC_EmployeeInfo/1.0.0/fetchuserdetails",
        getCompanies: "CSC_NJ_CompanyMaster/1.0.0/company/fetchSapActiveCompanyData",
        getYear: "DT_NC_Period/1.0.0/GetPeriod"
    },
    FILE_API: {
        'exportToExcel': 'CU_NJ_ExcelValidate/1.0.0/download/excelSimple',
        'uploadARfile' : TRPC + 'uploadARfile',
        'getARDetails':TRPC +'getARDetails'
    },
    RECO:{
        getheaderReco: TRPC+"getheaderReco",
        getheaderdetails:TRPC+"getheaderdetails",
        getitemdetails:TRPC+"getitemdetails",
        ignoreItems:TRPC+"ignoreItems",
        unignoreItems:TRPC+"unignoreItems",
        sendToTPApproval : TRPC + "sendToTPApproval",
        getignoreitemdetails:TRPC +"getignoreitemdetails"
    },
    REVIEW:{
        getheaderTpr:TRPC+"getheaderTpr",
        pushTo_Summary : TRPC + "pushToSummary",
        raiseQuery : TRPC + "pushBackToRPT",
    },
    SUMMARY:{
        getReviewSummary:TRPC+"getReviewSummary",
        getMISManualSummary : TRPC + "getMISManualSummary",
        getVerifiedSummary : TRPC + "getVerifiedSummary",
    }

}

export const BASEURLS = {
    BASE: environment.isWSO2 ? 'wso2url' : 'apiURL',
    BASEURL: 'apiWSO2URL',
    COMMON: 'apiCommonURL',
    AUTH: 'ssoURL',
    DP: 'digitalURL',
    ACCESS: 'accessURL'
}