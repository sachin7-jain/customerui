export const InterceptorSkipHeader = 'X-Skip-Interceptor';
export const LOGIN = 'login';
export const DEFAULT = 'forbidden';

export let PERM = {
    Preparer : [
        {
            ob : "",
            actvt: "Preparer"
        }
    ],
    ReviewVerify : [
        {
            ob : "",
            actvt: "ReviewVerify"
        }
    ]
}