import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'searchByKeyFilter' })
export class SearchByKeyFilterPipe implements PipeTransform {
  transform(items: any, searchText: any, key: string,key2:string): any {
    if (searchText == null) return items;
    return items.filter((search) => {
      if (search[key] != null && search[key2] !=null) { 
        return search[key].toLowerCase().indexOf(searchText.toLowerCase()) > -1 || search[key2].toLowerCase().indexOf(searchText.toLowerCase()) > -1}
        else if(search[key] != null){
          return search[key].toLowerCase().indexOf(searchText.toLowerCase()) > -1
        }
    })
  }
}