import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ForbiddenComponent } from './modules/forbidden/forbidden.component';
import { LoginComponent } from './components/login/login.component';
import { AuthGuard } from './services/authguard/guard.service';

const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent,
    data: {
      title: 'Retail Assets | Login'
    }
  },
  {
    path: 'forbidden',
    loadChildren: () => import('./modules/forbidden/forbidden.module').then(m => m.ForbiddenModule)
  },
  {
    path: '',
    canActivate: [AuthGuard],
    loadChildren: () => import('./modules/main/main.module').then(m => m.MainModule)
  },
  {
    path: '**',
    redirectTo: 'login',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule { }
