import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss']
})
export class NotificationComponent implements OnInit {
  newForm: FormGroup;
  openMenu=true;
  dynamicNotification: any[] = [
    {"isRead":"true","createdDate":"28-10-2021","header":"Query","msg":"Kindly update","action":"Provide resolution"},
    {"isRead":"true","createdDate":"27-10-2021","header":"Query","msg":"Kindly update","action":"view items"},
    {"isRead":"true","createdDate":"27-10-2021","header":"Query","msg":"Kindly update","action":"view items"}
 
  ];
  constructor() { }

  ngOnInit(): void {
  }
  onNotificationClick(){

  }
  action(){
    //this.dialogRef.close();
 

  }
  closeModal(){
   this.openMenu=false;
  }
}
