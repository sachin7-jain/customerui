
import { Subscription } from "rxjs";

import {
  Component,
  EventEmitter,
  Output,
  ChangeDetectorRef,
  ViewEncapsulation,
  OnInit,
  ViewChild,
} from "@angular/core";
import { faSearch } from "@fortawesome/free-solid-svg-icons";
import { Router } from "@angular/router";
import { CommonService } from "../common.service";
import { AuthService } from "src/app/services/auth.service";
import { environment } from "src/environments/environment";
import { NotificationComponent } from 'src/app/layout/header/notification/notification.component';
import { MatDialog } from "@angular/material/dialog";
import { MatDrawer, MatDrawerContainer } from "@angular/material/sidenav";



@Component({
  selector: "header",
  templateUrl: "./header.component.html",
  styleUrls: ["./header.component.scss"],
  encapsulation: ViewEncapsulation.None,
})
export class HeaderComponent implements OnInit {
  @ViewChild("drawer") public drawer: MatDrawer;
 
  notificationCount: any = 2;   //if notificationCount>0 show warn colored badge = count on bell
  count=1;  
  openMenu = false;
  public faSearch = faSearch;
  overlayReq: boolean = false;
  xsMobileQuery: MediaQueryList;
  mobileQuery: MediaQueryList;
  notificationSubscripton: Subscription;
  public notifications = [];
  public latestNotifications = [];
  private latestNotificationCount: number = 3;
  private _mobileQueryListener: () => void;
  user:any={};
  notificationIcons: any;
  redirectUrls: any;
  profileInfo:any
  public hasUnreadNotifications: boolean = false;
  constructor(
    private router: Router,  
    private auth: AuthService,
    private commonService: CommonService,
    private _md: MatDialog,

  ) { }
 
  ngOnInit() { 
    this.auth.getUserSub().subscribe(res => {
      this.user = res;
    })
  }
  logout() {   
    this.auth.logout(); 
  }
  onToggleSidenav(){
    this.commonService.toggle();
  }
  onReportProblem() {
    let url = environment["reportIssueUrl"];
    window.open(url, "_blank");
  }
  openNotification(){    
    const dialogRef = this._md.open(NotificationComponent, { width:'500px',      
    });
    dialogRef.afterClosed().subscribe((o) => {      
    });
  }

  getNotification() {
   // this.dynamicNotification = ["1","2"];
    this.notificationCount = ''; 
  }
  onNotificationClick(item){

  }

  toggleOption(){
    if(this.openMenu){
      this.openMenu = false;
    }else{
      if(this.count>0)
      this.openMenu = true;
    }
  }
}