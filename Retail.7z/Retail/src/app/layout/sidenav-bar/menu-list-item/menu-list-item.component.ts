import {Component, HostBinding, Input,EventEmitter, OnInit, Output} from '@angular/core';
import {NavItem} from '../nav-item';
import {Router} from '@angular/router';
import { CommonService } from '../../common.service';
import { menuAnimation, indicatorRotate } from '../animations';
import { menu } from 'src/app/constants/routes';
import { MainService } from 'src/app/modules/main/main/main.service';
@Component({
  selector: 'app-menu-list-item',
  templateUrl: './menu-list-item.component.html',
  styleUrls: ['./menu-list-item.component.scss'],
  
  animations: [menuAnimation,indicatorRotate]
})
export class MenuListItemComponent implements OnInit {
  expanded: boolean=true;
  menuList: any;
  isOpened = false;
  @Input() selectedItem: string = "transfer-pricing-details";
  @HostBinding('attr.aria-expanded') ariaExpanded = this.expanded;
  @Input() item: NavItem;
  @Input() depth: number;
  @Output() onItemSelected =new EventEmitter<any>();
  toDisable:boolean = false;
  constructor(public router: Router,
    private service: CommonService,private ms:MainService) {
    if (this.depth === undefined) {
      this.depth = 0;
    }
  }

  ngOnInit() {
    this.menuList=menu.map(r=>r.data);
    this.service.openSubject.subscribe(open=> this.isOpened = open);
    this.ms.isValuesSelected.subscribe(res=> this.toDisable = res);
  }
  itemSelected(ev,item: NavItem): void {
    if(ev.target.innerText=="expand_more"){
      this.isOpened = !this.isOpened;
      return;
    }
    this.selectedItem="";
    if (item.children && item.children.length) {
        this.isOpened = !this.isOpened;
    }
    this.selectedItem = item.title;
    this.onItemSelected.emit(item);
  }
  subMenuListItemClick(item: NavItem): void {
    this.selectedItem="";
    this.selectedItem = item.title;
    this.isOpened = false;
    this.onItemSelected.emit(item);
  }
}
