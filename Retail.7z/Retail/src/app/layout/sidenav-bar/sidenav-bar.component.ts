import {
  Component,
  OnInit,
  OnDestroy,
  ChangeDetectorRef,
  ViewChild,
  ViewEncapsulation,
  HostBinding,
  Input,
} from "@angular/core";
import { CommonService } from "../common.service";
import { Router, NavigationEnd } from "@angular/router";
import { MediaMatcher } from "@angular/cdk/layout";
import { MatDrawer } from "@angular/material/sidenav";
import { hideAnimation} from './animations';
import { NavItem } from "./nav-item";
import { menu } from 'src/app/constants/routes';
import { PermissionService } from 'src/app/services/perm.service';
// import { UserService } from "src/app/core/services/user.service";

@Component({
  selector: "app-sidenav-bar",
  templateUrl: "./sidenav-bar.component.html",
  styleUrls: ["./sidenav-bar.component.css"],
  encapsulation: ViewEncapsulation.None,
  animations: [hideAnimation]
})
export class SidenavBarComponent implements OnInit, OnDestroy {
  menuList: any;
  mobileQuery: MediaQueryList;
  desktopQuery: MediaQueryList;
  xlDesktopQuery: MediaQueryList;
  private _mobileQueryListener: () => void;
  @ViewChild("drawer") public drawer: MatDrawer;
  certifyFlag: boolean = true;
  EducertifyFlag: boolean = true;
  selectedItem: string = "transfer-pricing-details";
  isOpened = false;
  expanded: boolean=false;
  menuMap:any={};
  @HostBinding('attr.aria-expanded') ariaExpanded = this.expanded;
  @Input() item: NavItem;
  @Input() depth: number;
  @Input()isExpand:boolean;
  constructor(
    private service: CommonService,
    private router: Router,
    private changeDetectorRef: ChangeDetectorRef,
    private media: MediaMatcher,
    private ps: PermissionService
   
  ) {
    
    this.mobileQuery = media.matchMedia("(max-width: 1279px)");
    this.desktopQuery = media.matchMedia("(min-width: 1280px)");
    this.xlDesktopQuery = media.matchMedia("(min-width: 1920px)");
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
    // router.events.subscribe((val) => {
    //   if(val instanceof NavigationEnd) {
    //     if (val.url) {
    //       const getPathName = val.url.split('/')[1];
    //       const getRouteInfo = this.routesList.find(x => x.routeName === getPathName);
    //       if (getRouteInfo) {
    //       //  this.selectedItem = getRouteInfo.menuName;
    //       }
    //     }
    //   }
    // });
  }

  ngOnInit(): void {
   this.menuList = menu.map(r => r.data);
  // this.menuList=menu.map(r=>r.data).filter(r => this.ps.hasPermissionSync(r.perm));
    this.menuList.forEach(row=>{
      if(row.forMenu){
        row.menuCount=this.menuMap[row.forMenu]?.length || 0;
        this.menuMap[row.forMenu]=[...(this.menuMap[row.forMenu] || []), row];       

      }
      // if(row.children && row.children.length>0){
      //   row.children = row.children.filter(r => this.ps.hasPermissionSync(r.perm))
      // }
    })
    this.menuList=this.menuList.filter(key=> !key.menuCount)
   // this.menuList = this.service.getMenuList;
     //this.isOpened = false;
     this.service.openSubject.subscribe(opened=> this.isOpened = opened);
  }

  
  ngAfterViewInit(): void {
    this.service.setDrawer(this.drawer);
    this.mobileQuery.addListener(this._mobileQueryListener);
  }

  gotoMenuLink(item: NavItem): void {
    this.selectedItem= item.title;
    this.isOpened = false;
    this.service.toggle();
    this.router.navigate([item.route]);
  }
  onToggleSidenav() {
    if (this.mobileQuery.matches) {
    }
  }
  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }
}
