export interface NavItem {
    title:string;
    header: string;
    img:string;
    alt:string;
    route?: string;
    height:string;
    width:string;
    inProd:boolean;
    perm?:[];
    children?: NavItem[];
    isChild?:boolean;
  }