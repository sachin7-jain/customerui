import {
  trigger,
  state,
  style,
  animate,
  transition
} from '@angular/animations';
export const indicatorRotate =
trigger('indicatorRotate', [
  state('collapsed', style({transform: 'rotate(0deg)'})),
  state('expanded', style({transform: 'rotate(180deg)'})),
  transition('expanded <=> collapsed',
    animate('225ms cubic-bezier(0.4,0.0,0.2,1)')
  ),
])
export const hideAnimation =
  trigger('hideAnimation', [
    state('opened', style({ 'min-width': 'auto' })),
    state('closed', style({  'min-width': '50px' })),
    transition('* => *', [
      animate(300)
    ]),
  ]);
export const contentAnimation =
  trigger('contentAnimation', [
    state('opened', style({ marginLeft: '{{size}}' }), { params: { size: '*'}}),
    state('closed', style({ marginLeft: '50px' })),
    transition('* => *', [
      animate(500)
    ]),
  ]);

export const menuAnimation =
  trigger('menuAnimation', [
    state('opened', style({ width: 'auto' })),
    state('closed', style({ width: '50px' })),
    transition('* => *', [
      animate(500)
    ])
  ]);