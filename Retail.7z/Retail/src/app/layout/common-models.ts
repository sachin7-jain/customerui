export const MENU_MASTER: any = [
  {
    name: "transfer-pricing-details",
    displayName: "Transfer Pricing Details",
    route: "home/transfer-pricing-details",
    iconImage: "sidebar-ico home-sidebar-ico",
    isVisible: true,
    inProd:true,
    icon:"assignment",
    children: [
      {
        name:'rpt',
        displayName: 'RPT with RECO',
        route: 'home/transfer-pricing-details/rpt',
        iconImage: "",
        inProd:true,
        icon:"assignment",
        isVisible: false,
      },      
      {
        name:'review',
        displayName: 'Transfer Price review',
        route: 'home/transfer-pricing-details/review',
        iconImage: "",
        inProd:true,
        icon:"assignment",
        isVisible: false,
      },
      {
        name:'summary',
        displayName: 'Transaction Summary',
        route: 'home/transfer-pricing-details/summary',
        iconImage: "",
        inProd:true,
        icon:"description",
        isVisible: false,
      },
      {
        name:'3ceb',
        displayName: 'Form 3CEB',
        route: 'home/transfer-pricing-details/3ceb',
        iconImage: "",
        inProd:true,
        icon:"library_books",
        isVisible: false,
      },
      {
        name:'mapping',
        displayName: 'Segment User Mapping',
        route: 'home/transfer-pricing-details/mapping',
        iconImage: "",
        inProd:true,
        icon:"library_books",
        isVisible: false,
      }
    ]
  },
  {
    name: "masters",
    displayName: "Masters",
    route: "home/masters",
    iconImage: "sidebar-ico performance-mgmt-sidebar-ico",
    isVisible: true,
    inProd:true,
    icon:"assignment",
    children:[{
      name:'main',
      displayName: 'Main Masters',
      route: 'home/masters/main',
      iconImage: "",
      inProd:true,
      icon:"assignment",
      isVisible: false,
    },{
      name:'associate',
      displayName: 'Associated Enterprise Master',
      route: 'home/masters/associate',
      iconImage: "",
      icon:"assignment",
      inProd:true,
      isVisible: false,
    }]
  },
  
];
export class IconsModel {
  icon: string;
  iconText: string;
  iconImageUrl: string;
  action: string;
  tooltipText: any;
  constructor(icon, iconText, iconImageUrl, action, tooltipText?) {
    this.icon = icon;
    this.iconText = iconText;
    this.iconImageUrl = iconImageUrl;
    this.action = action;
    this.tooltipText = tooltipText;
  }
}
export class MarketIconsModel {
  //icon: string;
  iconImageUrl: string;
  action: string;
  constructor(iconImageUrl, action) {
    //this.icon = icon;
    this.iconImageUrl = iconImageUrl;
    this.action = action;
  }
}
