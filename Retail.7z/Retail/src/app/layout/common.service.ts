import { Injectable } from "@angular/core";
import { MENU_MASTER } from "./common-models";
import { MatDrawer } from "@angular/material/sidenav";
import { BehaviorSubject } from "rxjs/internal/BehaviorSubject";

@Injectable()
export class CommonService {
  private drawer: MatDrawer;
  isOpened = true;
  openSubject = new BehaviorSubject(true);
  constructor() {
  }
  get getMenuList() {
    return MENU_MASTER;
  }
  setDrawer(drawer: MatDrawer) {
    this.drawer = drawer;
  }
  toggle(): void {
    this.isOpened = !this.isOpened;
    this.openSubject.next(this.isOpened);
  }
  openAnimation() {
   return this.isOpened;    
  }
}
