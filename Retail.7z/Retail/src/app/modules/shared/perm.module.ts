import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PermDirective, PermHiddenDirective } from 'src/app/directives/perm.directive';



@NgModule({
  declarations: [
    PermDirective,
    PermHiddenDirective
  ],
  imports: [
    CommonModule
  ],
  exports: [
    PermDirective,
    PermHiddenDirective
  ]
})
export class PermModule { }
