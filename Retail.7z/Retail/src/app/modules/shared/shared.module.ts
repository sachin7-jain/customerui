import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PermModule } from './perm.module';
import { SmoothHeightAnimDirective } from 'src/app/directives/grow.directive';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { APMLogDirective } from 'src/app/apm-rum';
import { NgxCustomModule } from 'src/app/components/ngx-custom/ngx-custom.module';
import { SearchByKeyFilterPipe } from 'src/app/pipes/dynamic.pipe';
import { PaginatiorStyleDirective } from 'src/app/directives/paginator-style.directive';
import { MaxCountDirective } from 'src/app/directives/maxcount.directive';
import {MatAutocompleteModule} from '@angular/material/autocomplete';


@NgModule({
  imports: [
    CommonModule,
    PermModule,
    NgxCustomModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatAutocompleteModule,
    ReactiveFormsModule
  ],
  declarations: [
    SmoothHeightAnimDirective,
    APMLogDirective,
    PaginatiorStyleDirective,
    MaxCountDirective
  ],  
  exports: [
    APMLogDirective,
    SmoothHeightAnimDirective,
    PaginatiorStyleDirective,
    PermModule,
    NgxCustomModule,
    MatInputModule,
    MatAutocompleteModule,
    ReactiveFormsModule,
    MaxCountDirective
  ]
})
export class SharedModule { }
