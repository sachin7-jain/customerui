import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MainRoutingModule } from './main-router.module';
import { MainComponent } from './main/main.component';
import { HeaderComponent } from 'src/app/layout/header/header.component';
import { FooterComponent } from 'src/app/layout/footer/footer.component';
import { SidenavBarComponent } from 'src/app/layout/sidenav-bar/sidenav-bar.component';
import { SharedModule } from '../shared/shared.module';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import {MatMenuModule} from '@angular/material/menu';
import { MatSidenavModule } from '@angular/material/sidenav';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatListModule } from '@angular/material/list';
import { MenuListItemComponent } from 'src/app/layout/sidenav-bar/menu-list-item/menu-list-item.component';
import {MatTooltipModule} from '@angular/material/tooltip';
import { MatDialogModule } from '@angular/material/dialog';
import { NotificationComponent } from 'src/app/layout/header/notification/notification.component';
import { MatBadgeModule } from '@angular/material/badge';

@NgModule({
  declarations: [
    HeaderComponent,
    FooterComponent,
    SidenavBarComponent,
    MainComponent,
    MenuListItemComponent,
    NotificationComponent
  ],
  imports: [
    CommonModule,
    MatIconModule,
    SharedModule,
    MainRoutingModule,
    MatCardModule,
    MatInputModule,
    FormsModule,
    MatMenuModule,
    MatSidenavModule,
    MatListModule,
    MatTooltipModule,
    FlexLayoutModule,
    MatDialogModule,
    MatBadgeModule,
    
  ],
  entryComponents: [],
  exports:[MenuListItemComponent,]
})
export class MainModule { }
