import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { HomeService } from './home.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  // _mastersList = [];
  backOption: boolean = false;
  isChild: boolean = true;
  prodmode;
  myopenitemsCount = 0;
  pendingwithothersCount = 0;
  swifttrackingCount = 0;
  tag="";
  permObjCommon = [
    {
      ob: "FX_SWFT",
      pcode: "FA11001"
    }
  ];
  permObjSwift = [
    {
      ob: "FX_SWFT",
      pcode: "FA11001"
    },
    {
      ob: 'FXTRACK',
      pcode: 'FA11002'
    }
  ]
  constructor(private _router: Router, private hs: HomeService) { }
  ngOnInit() {
    this.prodmode = environment.production;
    this.hs.getCount().subscribe(r => {
      this.myopenitemsCount = r.data.filter(r => r.OpenItemsCount !== undefined)[0].OpenItemsCount;
      this.pendingwithothersCount = r.data.filter(r => r.pendingItemsCount !== undefined)[0].pendingItemsCount;
    })
  }
  selectTab(url) {
    this._router.navigate(['/', url,this.tag]);
  }
  selectSubTab(url,tags){
    this.tag=tags;
    this.selectTab(url);
  }
  
}

