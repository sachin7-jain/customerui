import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { APIS, BASEURLS } from 'src/app/constants/end-points';
import { SharedHttpService } from 'src/app/services/http.service';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  constructor(private http: SharedHttpService) { }

  getCount():Observable<any>{
    return this.http.get(BASEURLS.BASE, APIS.dashboard.getcount);
  }
}
