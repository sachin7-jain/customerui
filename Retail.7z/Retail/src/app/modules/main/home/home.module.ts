import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { PermModule } from '../../shared/perm.module';
const routes:Routes = [
  {
    path: '',
    component: HomeComponent
  },
]

@NgModule({
  declarations: [
    HomeComponent
  ],
  imports: [
    SharedModule,
    PermModule,
    RouterModule.forChild(routes),
    CommonModule
  ],
  entryComponents: []
})
export class HomeModule { }
