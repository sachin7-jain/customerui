import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { menu } from 'src/app/constants/routes';
import { SharedModule } from '../shared/shared.module';
import { MainGuard } from './main.guard';
import { MainComponent } from './main/main.component';


const routes: Routes = [
    {
        path: '',
        component: MainComponent,
        canActivateChild: [MainGuard],
        children: [
            ...menu,
            
            {
                path: '**',
                redirectTo: 'dashboard',
                pathMatch: 'full'
            }
        ]
    },
   
    {
        path: '**',
        redirectTo: '',
        pathMatch: 'full'
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes),SharedModule,CommonModule],
    schemas:[CUSTOM_ELEMENTS_SCHEMA],
    exports: [RouterModule],
    
})
export class MainRoutingModule { }
