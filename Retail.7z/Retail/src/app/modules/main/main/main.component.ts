import { Component, OnInit } from '@angular/core';
import { MainService } from './main.service';
import { NotifyService } from 'src/app/services/notify.service';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss'],
})

export class MainComponent implements OnInit {
  constructor(private ms:MainService,private not:NotifyService) { }
  ngOnInit(): void {
    // this.getCompanies();
    // this.getYear();
  }
  getCompanies(){
    let obj ={
      "Logsys": "RD2CLNT214",
      "Company_Code": [
      "RIL","RP01","FCPL"
      ],
      "Active_Flag": "X",
      "fields": [
      "Logsys","Company_Code","Company_Name"
      ]
    }
    this.ms.getCompanies(obj).subscribe(
      (res)=>{
      },(err)=>{
        this.not.errorMessage(err);
      }
    )
  }

  getYear(){
    this.ms.getYear().subscribe(
      (res)=>{
        console.log(res)
      },(err)=>{
        this.not.errorMessage(err);
      }
    )
  }
}
