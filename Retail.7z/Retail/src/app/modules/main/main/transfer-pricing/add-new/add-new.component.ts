import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { NotifyService } from 'src/app/services/notify.service';
import { AddRecordsModel } from './add-records.model';

@Component({
  selector: 'app-add-new',
  templateUrl: './add-new.component.html',
  styleUrls: ['./add-new.component.scss']
})
export class AddNewComponent implements OnInit {
  header;
  kotakform: FormGroup;
  isAdd:boolean=true;
  ApplicantTypeList=[{"id":"indivisual","name":"Indivisual"},{"id":"entity","name":"Entity"}];
  IncomeTypeList=[{"id":"salaried","name":"Salaried"},{"id":"self","name":"Self Employed"}];
  ResidentStatusList=[{"id":"indian","name":"Resident Indian"},{"id":"nri","name":"NRI"}];
  GenderList=[{"id":"male","name":"Male"},{"id":"female","name":"Female"}];
  constructor(
    @Inject(MAT_DIALOG_DATA) public data,
    private dialogRef: MatDialogRef<AddNewComponent>,
    // private segService: SegmentUserMappingService,
    private notif: NotifyService
  ) { }

  ngOnInit(): void {
    this.createForm();
    this.isAdd = this.data.isAdd;
    this.getSegments();
    this.header=this.data.header;
  }


  getSegments() {
    // this.segService.fetchSegment().subscribe(
    //   (res) => {
    //     console.log(res);
    //     res.data.forEach((x) => {
    //       this.segList.push({
    //         value: x.segment, name: x.segment
    //       })
    //     })
    //   }, (err) => {
    //     this.notif.errorMessage(err);
    //   }
    // )
  }

  createForm() {
    this.kotakform = new FormGroup({
      ApplicantType: new FormControl(null),
      IncomeType: new FormControl(null),
      ResidentStatus: new FormControl(null),
      Gender: new FormControl(null),
      FirstName: new FormControl(null),
      LastName: new FormControl(null),
      EmailId: new FormControl(null),
      MobileNumber: new FormControl(null),
      AlternateMobileNumber: new FormControl(null),
      IsTncAgree: new FormControl(null)
    })
  }

  onCancel(){
    this.dialogRef.close(false);
    this.kotakform.reset();
  }

  onSave(){
    this.dialogRef.close(true);
    let modelData=new AddRecordsModel(this.kotakform.getRawValue());
    console.log(modelData);
  }

}
