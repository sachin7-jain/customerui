import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
 import { TransferPricingComponent } from './transfer-pricing.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RilDataTableModule } from 'src/app/components/ril-data-table/ril-data-table.module';
import { MatTabsModule } from '@angular/material/tabs';
import { SharedModule } from 'src/app/modules/shared/shared.module';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatTableModule } from '@angular/material/table';
import {MatCheckboxModule} from '@angular/material/checkbox';
import { AddNewComponent } from './add-new/add-new.component';
const routes: Routes = [
      {
        path: '',
        component: TransferPricingComponent,
      },
      
  {
    path: '**',
    redirectTo: '',
    pathMatch: 'full'
  }
];



@NgModule({
  declarations: [TransferPricingComponent, AddNewComponent],
  imports: [
    RouterModule.forChild(routes),
    CommonModule,
    FlexLayoutModule,
    RilDataTableModule,
    MatTabsModule,
    SharedModule,
    MatSidenavModule,
    MatTableModule,
    MatCheckboxModule
  ],
  exports:[RouterModule,MatSidenavModule],
  providers:[],
  schemas:[CUSTOM_ELEMENTS_SCHEMA],
})
export class TransferPricingModule {}
