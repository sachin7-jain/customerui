export class AddRecordsModel {
    RequestId:number;
    ApplicantType:string;
    IncomeType:string;
    ResidentStatus: string;
    Gender: string;
    FirstName: string;
    LastName: string;
    EmailId: string;
    MobileNumber: string;
    AlternateMobileNumber: string;
    IsTncAgree: string;
    Status: string;
    CreatedOn: string;
    CreatedBy:string;
    constructor(data){
        if(data.ApplicantType)
        this.ApplicantType=data.ApplicantType;
        if(data.IncomeType)
        this.IncomeType=data.IncomeType;
        if(data.IncomeType)
        this.IncomeType=data.IncomeType;
        if(data.ResidentStatus)
        this.ResidentStatus=data.ResidentStatus;
        if(data.Gender)
        this.Gender=data.Gender;
        if(data.FirstName)
        this.FirstName=data.FirstName;
        if(data.LastName)
        this.LastName=data.LastName;
        if(data.EmailId)
        this.EmailId=data.EmailId;
        if(data.MobileNumber)
        this.MobileNumber=data.MobileNumber;
        if(data.IsTncAgree)
        this.IsTncAgree=data.IsTncAgree;
        if(data.AlternateMobileNumber)
        this.AlternateMobileNumber=data.AlternateMobileNumber
    }
  }