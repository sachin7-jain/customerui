import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { RilTableModel } from 'src/app/components/ril-data-table/ril-data-table.model';
import { CookieService } from 'src/app/services/cookie.service';
import { AddNewComponent } from './add-new/add-new.component';

@Component({
  selector: 'app-transfer-pricing',
  templateUrl: './transfer-pricing.component.html',
  styleUrls: ['./transfer-pricing.component.css']
})
export class TransferPricingComponent implements OnInit { 
  displayColumns=[];
 
  oRilTableModel: RilTableModel;
  data=[{
    "RequestId":1,
    "ApplicantType":"Individual",
    "IncomeType":"Salaried",
    "ResidentStatus":"Indian",
    "Gender":"Female",
    "FirstName":"Mira",
    "LastName":"Kane",
    "EmailId":"mira.karale@ril.com",
    "MobileNumber":"9921234625",
    "AlternateMobileNumber":"9284208539",
   "Status":"Active",
   "CreatedOn":"29/11/2021",
   "CreatedBy":"Sachin Jain"
  },
  {
    "RequestId":2,
    "ApplicantType":"Individual",
    "IncomeType":"Salaried",
    "ResidentStatus":"Indian",
    "Gender":"Male",
    "FirstName":"Kishor",
    "LastName":"Jain",
    "EmailId":"kishor.jain@ril.com",
    "MobileNumber":"998989898",
    "AlternateMobileNumber":"N.A",
   "Status":"Active",
   "CreatedOn":"31/11/2021",
   "CreatedBy":"Sachin Jain"
  }]
  columns = [
    { columnDef: 'RequestId', header: 'Request ID',sticky:true, isTooltipVisible: true, cell: (element: any) => `${element.RequestId ? element.RequestId : ''}` },
    { columnDef: 'ApplicantType', header: 'Applicant Type',sticky:true, isTooltipVisible: true, cell: (element: any) => `${element.ApplicantType ? element.ApplicantType : ''}` },
    { columnDef: 'IncomeType', header: 'Income Type',sticky:true, isTooltipVisible: true, cell: (element: any) => `${element.IncomeType ? element.IncomeType : ''}` },
    { columnDef: 'ResidentStatus', header: 'Resident Status',sticky:true, isTooltipVisible: true, cell: (element: any) => `${element.ResidentStatus ? element.ResidentStatus : ''}` },
    { columnDef: 'Gender', header: 'Gender',sticky:true, isTooltipVisible: true, cell: (element: any) => `${element.Gender ? element.Gender : ''}` },
    { columnDef: 'FirstName', header: 'First Name',sticky:true, isTooltipVisible: true, cell: (element: any) => `${element.FirstName ? element.FirstName : ''}` },
    { columnDef: 'LastName', header: 'Last Name',sticky:true, isTooltipVisible: true, cell: (element: any) => `${element.LastName ? element.LastName : ''}` },
    { columnDef: 'EmailId', header: 'Email ID',sticky:true, isTooltipVisible: true, cell: (element: any) => `${element.EmailId ? element.EmailId : ''}` },
    { columnDef: 'MobileNumber', header: 'Mobile Number',sticky:true, isTooltipVisible: true, cell: (element: any) => `${element.MobileNumber ? element.MobileNumber : ''}` },
    { columnDef: 'AlternateMobileNumber', header: 'Alternate Mobile Number',sticky:true, isTooltipVisible: true, cell: (element: any) => `${element.AlternateMobileNumber ? element.AlternateMobileNumber : ''}` },
    { columnDef: 'Status', header: 'Status',sticky:true, isTooltipVisible: true, cell: (element: any) => `${element.Status ? element.Status : ''}` },
    { columnDef: 'CreatedOn', header: 'Created On',sticky:true, isTooltipVisible: true, cell: (element: any) => `${element.CreatedOn ? element.CreatedOn : ''}` },
    { columnDef: 'CreatedBy', header: 'Created By',sticky:true, isTooltipVisible: true, cell: (element: any) => `${element.CreatedBy ? element.CreatedBy : ''}` },

  ];

  constructor( private dialog: MatDialog,private cookie:CookieService,) { }

  ngOnInit(): void {
    this.displayColumns = ['RequestId', 'ApplicantType', 'IncomeType', 'ResidentStatus', 'Gender', 'FirstName', 'LastName',
    'EmailId','MobileNumber','AlternateMobileNumber','Status','CreatedOn','CreatedBy','action'];
    this.initializeApproverMatDataCB([]);
    this.getSummaryTableData();
  }
  
  getSummaryTableData(){
    this.initializeApproverMatDataCB(this.data);
  }
  initializeApproverMatDataCB(data: Array<any>) {
    this.oRilTableModel = new RilTableModel();
    this.oRilTableModel.pageSize = 10;
    this.oRilTableModel.columns = this.columns;
    this.oRilTableModel.dataSource = data;
    this.oRilTableModel.btnActionAdd = true;
    this.oRilTableModel.showSearch=true;
    this.oRilTableModel.paginatorShow=true;
    this.oRilTableModel.displayedColumns = this.displayColumns;
  }
  onAdd() {
    this.dialog.open(AddNewComponent, {
      width: '1000px' , 
      data : {isAdd:true,header:"Let’s start with your basic details",data:{}}
    }).afterClosed().subscribe(res=>{
      if(res){
        // this.getSegmentUserMapping();
      }
    });

  }

  onEdit(row) {
    console.log(row)
    this.dialog.open(AddNewComponent, {
      width: '1000px',
      data : {isAdd:false,data:row}
    }).afterClosed().subscribe(res=>{
      if(res){
        // this.getSegmentUserMapping();
      }
    });
   }

}

