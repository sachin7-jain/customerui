import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { APIS, BASEURLS } from 'src/app/constants/end-points';
import { SharedHttpService } from 'src/app/services/http.service';

@Injectable({
    providedIn: 'root'
  })
export class MainService {
    isValuesSelected = new BehaviorSubject(false);
    constructor(private http: SharedHttpService) { }

    getCompanies(data): Observable<any> {
        return this.http.post(BASEURLS.BASE, APIS.USER_API.getCompanies,data);
    }

    getYear(): Observable<any> {
        return this.http.get(BASEURLS.BASE, APIS.USER_API.getYear);
    }

    uploadARfile(data): Observable<any> {
        return this.http.post(BASEURLS.BASE, APIS.FILE_API.uploadARfile, data);
    }
    getARDetails(data): Observable<any> {
        return this.http.get(BASEURLS.BASE, APIS.FILE_API.getARDetails, {queryParams:data});
    }
    checkValue(event){
        this.isValuesSelected.next(event);
    }
}