import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router, CanActivateChild } from '@angular/router';
import { Observable } from 'rxjs';
import { DEFAULT, LOGIN } from 'src/app/constants/const';
import { menu } from 'src/app/constants/routes';
import { PermissionService } from 'src/app/services/perm.service';
import { AuthService } from '../../services/auth.service'

@Injectable({
    providedIn: 'root'
})
export class MainGuard implements CanActivateChild {
    constructor(private authsrv: AuthService, private router: Router, private perm: PermissionService) { }
    canActivateChild(
        next: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
        let firstMenu = menu.map(r => r.data);
        let def = DEFAULT;
        if (firstMenu && firstMenu.length > 0) {
            def = firstMenu[0].route;
        }
        if (this.authsrv.isAuthorized()) {
            // if (!this.perm.hasPermissionSync(next.data.perm)) {
            //     this.router.navigate([def]);
            //     return false;
            // }
            //else
                return true;
        }
        else {
            if (state.url.indexOf(LOGIN) !== -1) {
                return false;
            }
        }
        this.router.navigateByUrl(def)
        return false;
    }
}
