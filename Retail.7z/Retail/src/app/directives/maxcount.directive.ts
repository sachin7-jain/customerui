import { Directive, Input, ElementRef, HostListener, Renderer2 } from '@angular/core';

@Directive({
  selector: '[showcount]'
})

export class MaxCountDirective {
  constructor(private el: ElementRef, private _renderer: Renderer2) {}
  text;
  formGroup: any;
  ngOnInit() {
    this.formGroup = this.el.nativeElement.closest('.mat-form-field-wrapper');//to traverse respective form-group
    var divElement = this._renderer.createElement("small"); //tag appending in form-group
    var text = this._renderer.createText(String(this.el.nativeElement.maxLength) + ' characters left') //MSG for the tag
    this._renderer.addClass(divElement, "pull-right"); // Class appending to tag
    this._renderer.addClass(divElement, "text-muted"); // Class appending to tag
    this._renderer.appendChild(divElement, text); // Insert message to tag
    this._renderer.appendChild(this.formGroup, divElement); //Insert tag to form-group
  }
  @HostListener("ngModelChange", ["$event"]) onKeyUp(value) {
    //Calculate the character length when field has a value already
    if(this.formGroup){
    this.formGroup.querySelectorAll("small")[0].innerHTML = String(this.el.nativeElement.maxLength - this.el.nativeElement.value.length) + ' characters left'
  }
  }
}