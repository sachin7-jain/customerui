import { Directive, Input, ElementRef, Renderer2 } from '@angular/core';
import { PermissionReq, PermissionService } from '../services/perm.service';

@Directive({
  selector: '[disableFor]'
})
export class PermDirective {

  constructor(private el: ElementRef, private perm: PermissionService, private render: Renderer2) { }

  @Input('disableFor') authObj: PermissionReq;
  ngOnInit() {
    this.ngOnChanges();
    let res = this.perm.hasPermissionSync([this.authObj]);
      if (res) {
        this.render.setAttribute(this.el.nativeElement, 'data-enable', 'true');
      }
      else {
        // this.render.setAttribute(this.el.nativeElement, 'data-enable', 'false');
        this.el.nativeElement.disabled = true
      }
  }

  ngOnChanges(){
    let res = this.perm.hasPermissionSync([this.authObj]);
    if (res) {
      this.render.setAttribute(this.el.nativeElement, 'data-enable', 'true');
    }
    else {
      // this.render.setAttribute(this.el.nativeElement, 'data-enable', 'false');
      this.el.nativeElement.disabled = true
    }
  }

  // ngOnDestroy() {
  // }
}


@Directive({
  selector: '[hiddenFor]'
})
export class PermHiddenDirective {

  constructor(private el: ElementRef, private perm: PermissionService, private render: Renderer2) { }

  @Input('hiddenFor') authObj: PermissionReq[];
  ngOnInit() {
    this.ngOnChanges();
    let res = this.perm.hasPermissionForButton(this.authObj);
      if (res) {
        this.render.setAttribute(this.el.nativeElement, 'data-visible', 'true');
      }
      else {
        // this.render.setAttribute(this.el.nativeElement, 'data-visible', 'false');
        this.el.nativeElement.style.display = "none"
      }
  }

  ngOnChanges(){
    let res = this.perm.hasPermissionForButton(this.authObj);
    if (res) {
      this.render.setAttribute(this.el.nativeElement, 'data-visible', 'true');
    }
    else {
      // this.render.setAttribute(this.el.nativeElement, 'data-visible', 'false');
      this.el.nativeElement.style.display = "none"
    }
  }

  // ngOnDestroy() {
  // }
}