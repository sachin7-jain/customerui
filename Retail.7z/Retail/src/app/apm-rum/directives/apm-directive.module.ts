import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { APMLogDirective } from '..';



@NgModule({
    declarations: [APMLogDirective],
    imports: [
        CommonModule
    ],
    exports: [APMLogDirective]
})
export class IconsimgModule { }
