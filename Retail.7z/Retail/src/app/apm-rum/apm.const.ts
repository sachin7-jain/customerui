export const apmTransactions = 
{
    '/ca': 'Consolidation Accountant, Consolidation Accountant',
    '/nta': 'Accountant, Accountant',
    '/master': 'Admin, Masters',
    '/nta/view': 'Accountant, View Notice to Account'
}